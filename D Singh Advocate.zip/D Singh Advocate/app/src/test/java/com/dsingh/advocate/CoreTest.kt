package com.dsingh.advocate

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class CoreTest {
    @Test fun leapYearPlusOneYear() { assertEquals("2025-02-28", addD("2024-02-29", 1, 'y')) }
    @Test fun plus30Days() { assertEquals("2026-12-24", addD("2026-11-24", 30, 'd')) }
    @Test fun s138Chain() {
        assertEquals("2026-02-09", addD("2026-01-10", 30, 'd'))
        val r = addD("2026-02-01", 15, 'd')
        assertEquals("2026-02-16", r)
        assertEquals("2026-03-18", addD(r, 30, 'd'))
    }
    @Test fun interestSimple() { assertEquals(12000.0, Calc.interest(100000.0, 12.0, 365.0, false), 0.01) }
    @Test fun interestCompoundOneYear() { assertEquals(12000.0, Calc.interest(100000.0, 12.0, 365.0, true), 0.01) }
    @Test fun sundayNote() { assertEquals(" ⚠ Sunday", dayNote("2026-11-22")) }
    @Test fun csvEscape() {
        assertEquals("\"a,b\"", Reports.csvEsc("a,b"))
        assertEquals("\"say \"\"hi\"\"\"", Reports.csvEsc("say \"hi\""))
    }
    @Test fun citations() {
        val l = citeList("See Section 138 of NI Act and Section 420 IPC.")
        assertTrue(l.any { it.startsWith("Section 138") })
        assertTrue(l.any { it.startsWith("Section 420") })
    }
    @Test fun cryptRoundTrip() {
        val d = File.createTempFile("dsa", ".bin")
        d.writeBytes(ByteArray(200000) { (it % 251).toByte() })
        val e = File.createTempFile("dsa", ".enc")
        val o = File.createTempFile("dsa", ".out")
        Crypt.encrypt(d, e, "pass123")
        assertTrue(Crypt.isEnc(e))
        assertTrue(Crypt.decrypt(e, o, "pass123"))
        assertArrayEquals(d.readBytes(), o.readBytes())
        assertFalse(Crypt.decrypt(e, File.createTempFile("dsa", ".bad"), "wrong"))
    }
    @Test fun monthReportSums() {
        val c = Case(title = "A", client = "X", fee = 1000, pays = listOf(Payment("2026-11-05", 400, "cash")),
            exps = listOf(Payment("2026-11-06", 100, "fee")))
        val r = Reports.monthReport(listOf(c), "2026-11")
        assertTrue(r.contains("400"))
        assertTrue(r.contains("Net"))
    }
}
