package com.dsingh.advocate

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class CoreTest {
    @Test fun leapYearPlusOneYear() { assertEquals("2025-02-28", addD("2024-02-29", 1, 'y')) }
    @Test fun plus30Days() { assertEquals("2026-12-24", addD("2026-11-24", 30, 'd')) }
    @Test fun s138Chain() {
        assertEquals("2026-02-09", addD("2026-01-10", 30, 'd'))
        val r = addD("2026-02-01", 15, 'd')
        assertEquals("2026-02-16", r)
        assertEquals("2026-03-18", addD(r, 30, 'd'))
    }
    @Test fun interestSimple() { assertEquals(12000.0, Calc.interest(100000.0, 12.0, 365.0, false), 0.01) }
    @Test fun interestCompoundOneYear() { assertEquals(12000.0, Calc.interest(100000.0, 12.0, 365.0, true), 0.01) }
    @Test fun sundayNote() { assertEquals(" ⚠ Sunday", dayNote("2026-11-22")) }
    @Test fun csvEscape() {
        assertEquals("\"a,b\"", Reports.csvEsc("a,b"))
        assertEquals("\"say \"\"hi\"\"\"", Reports.csvEsc("say \"hi\""))
    }
    @Test fun citations() {
        val l = citeList("See Section 138 of NI Act and Section 420 IPC.")
        assertTrue(l.any { it.startsWith("Section 138") })
        assertTrue(l.any { it.startsWith("Section 420") })
    }
    @Test fun cryptRoundTrip() {
        val d = File.createTempFile("dsa", ".bin")
        d.writeBytes(ByteArray(200000) { (it % 251).toByte() })
        val e = File.createTempFile("dsa", ".enc")
        val o = File.createTempFile("dsa", ".out")
        Crypt.encrypt(d, e, "pass123")
        assertTrue(Crypt.isEnc(e))
        assertTrue(Crypt.decrypt(e, o, "pass123"))
        assertArrayEquals(d.readBytes(), o.readBytes())
        assertFalse(Crypt.decrypt(e, File.createTempFile("dsa", ".bad"), "wrong"))
    }
    @Test fun monthReportSums() {
        val c = Case(title = "A", client = "X", fee = 1000, pays = listOf(Payment("2026-11-05", 400, "cash")),
            exps = listOf(Payment("2026-11-06", 100, "fee")))
        val r = Reports.monthReport(listOf(c), "2026-11")
        assertTrue(r.contains("400"))
        assertTrue(r.contains("Net"))
    }
    @Test fun parseDateNamedMonth() {
        val d = LocalParse.parseDate("Ram Kumar ke case ki agli hearing 15 December ko hai")
        assertTrue(d != null && d.endsWith("-12-15"))
    }
    @Test fun parseDateNumeric() { assertEquals("2030-01-20", LocalParse.parseDate("agli tareekh 20/01/2030")) }
    @Test fun parseDateHindiDigits() {
        val d = LocalParse.parseDate("अगली हियरिंग १५ दिसंबर को")
        assertTrue(d != null && d.endsWith("-12-15"))
    }
    @Test fun parseDateKal() { assertEquals(today().plusDays(1).toString(), LocalParse.parseDate("kal ki tareekh")) }
    @Test fun matchCaseByName() {
        val a = Case(title = "Ram Kumar vs State", client = "Ram Kumar")
        val b = Case(title = "Sita Devi vs Mohan", client = "Sita Devi")
        val m = LocalParse.matchCases("ram kumar ke case ki agli hearing", listOf(a, b))
        assertEquals(1, m.size)
        assertEquals("Ram Kumar", m[0].client)
    }
    @Test fun landTriangle() { assertEquals(6.0, Land.heron(3.0, 4.0, 5.0)!!, 0.0001) }
    @Test fun landQuadRectAvg() { assertEquals(5000.0, Land.quadAvg(100.0, 50.0, 100.0, 50.0), 0.0001) }
    @Test fun landBrahmaguptaSquare() { assertEquals(100.0, Land.brahmagupta(10.0, 10.0, 10.0, 10.0)!!, 0.0001) }
    @Test fun landQuadDiagonal() { assertEquals(100.0, Land.quadDiag(10.0, 10.0, 10.0, 10.0, Math.sqrt(200.0))!!, 0.0001) }
    @Test fun landInvalidTriangle() { assertTrue(Land.heron(1.0, 2.0, 10.0) == null) }
    @Test fun landValueAndDuty() {
        val o = Land.compute(Land.In(1000.0, 1.0, 2000.0, 2500.0, 0, 6.0, 1.0, 1.0, 0.0, 0, 2.0, 0.0, 0.0, 0.0))
        assertEquals(2000000.0, o.deal, 0.01)
        assertEquals(2500000.0, o.circle, 0.01)
        assertEquals(2500000.0, o.base, 0.01)
        assertEquals(150000.0, o.stamp, 0.01)
        assertEquals(1500.0, o.sur, 0.01)
        assertEquals(25000.0, o.reg, 0.01)
        assertEquals(40000.0, o.road, 0.01)
        assertEquals(2216500.0, o.total, 0.01)
    }
    @Test fun landSqYardUnit() { assertEquals(9.0, Land.AREA.first { it.first.startsWith("gaj") }.second, 0.0) }
    @Test fun indianGrouping() {
        assertEquals("₹1,23,45,678", inrIN(12345678.0))
        assertEquals("₹12,345", inrIN(12345.0))
        assertEquals("₹999", inrIN(999.0))
    }
}
