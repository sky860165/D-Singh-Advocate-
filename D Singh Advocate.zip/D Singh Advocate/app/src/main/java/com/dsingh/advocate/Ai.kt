package com.dsingh.advocate

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Anon {
    var map: Map<String, String> = emptyMap()
    fun set(c: Case) {
        val m = LinkedHashMap<String, String>()
        if (c.client.isNotBlank()) m[c.client.trim()] = "[CLIENT]"
        if (c.opp.isNotBlank()) m[c.opp.trim()] = "[OPPOSITE PARTY]"
        if (c.phone.isNotBlank()) m[c.phone.trim()] = "[PHONE]"
        map = m
    }
    fun mask(s: String): String { var r = s; map.forEach { (k, v) -> r = r.replace(k, v, ignoreCase = true) }; return r }
    fun unmask(s: String): String { var r = s; map.forEach { (k, v) -> r = r.replace(v, k) }; return r }
}

fun citeList(t: String): List<String> =
    Regex("(?i)\\b(?:section|sec\\.?|s\\.)\\s*\\d{1,4}[A-Za-z]?(?:\\(\\d+\\))?(?:\\s*(?:of|,)?\\s*(?:the\\s+)?(?:BNSS|BNS|BSA|IPC|CrPC|CPC|NI Act|Evidence Act|Indian Penal Code))?")
        .findAll(t).map { it.value.trim() }.distinct().take(15).toList()

object Ai {
    @Volatile var netFail = false

    const val SYS = """Tum ek experienced Indian advocate ke legal assistant ho. Indian law ke hisaab se kaam karo: nayi BNS/BNSS/BSA (1 July 2024 se) ko prefer karo aur zarurat par purani IPC/CrPC/Evidence Act ka reference bhi do. Drafts court ke standard format me likho (cause title, parties, numbered paragraphs, prayer, verification aur advocate signature block). Jo details nahi di gayi unke liye [BRACKET] placeholder rakho, kuch invent mat karo. Language: user ki language follow karo (Hindi/Hinglish/English); formal draft ke liye user jo bole wahi language. Aakhir me chhota note do ki advocate verify kare, aur kaunse sections ya judgments verify karne hain. Case-law ka naam tabhi do jab pakka yaad ho, warna 'verify karo' likho."""

    const val ANALYZE = """Ye ek case file ki PDF hai. Advocate ke liye Hinglish me, headings ke saath ye 6 cheezein nikalo: 1) Case ka summary 2) Important facts (timeline ke saath) 3) Relevant legal provisions (BNS/BNSS/BSA ya jo Act laage) 4) Opposite party ke possible arguments 5) Hamare possible counter-arguments 6) Draft arguments (court me bolne layak, point-wise). Aakhir me batao PDF me kya missing ya unclear hai aur kya verify karna hai. Sirf PDF me jo likha hai uske basis par bolo."""

    const val ORDER = """Ye kisi court order / judgment / document ki photo ya PDF hai. Hinglish me batao: 1) Kya document hai (court, case no., date) 2) Main directions / operative part 3) Agli tareekh ya deadlines (agar likhi hain) 4) Advocate ko kya action lena chahiye. Jo padha nahi ja raha uska zikr karo, guess mat karo."""

    suspend fun ask(prompt: String, system: String = SYS, pdf: ByteArray? = null, json: Boolean = false, mime: String = "application/pdf", queue: Boolean = true): String =
        withContext(Dispatchers.IO) {
            val key = Prefs.key
            if (key.isBlank()) { Anon.map = emptyMap(); return@withContext "ERR: Settings me Gemini API key daalo." }
            if (!Net.online && queue) {
                if (pdf != null || json) { Anon.map = emptyMap(); return@withContext "ERR: 📴 Internet nahi hai. Ye kaam (PDF/photo analysis) net par hi hota hai, net aane par dobara try karo." }
                AiQueue.add(prompt, prompt.take(40).replace("\n", " "), system)
                Anon.map = emptyMap()
                return@withContext "📴 Internet nahi hai. Request AI Inbox me save ho gayi, net aate hi apne aap chalegi aur notification milega."
            }
            try {
                netFail = false
                val parts = JSONArray()
                if (pdf != null) parts.put(JSONObject().put("inline_data", JSONObject()
                    .put("mime_type", mime).put("data", Base64.encodeToString(pdf, Base64.NO_WRAP))))
                parts.put(JSONObject().put("text", Anon.mask(prompt)))
                val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                if (system.isNotBlank()) body.put("system_instruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                if (json) body.put("generationConfig", JSONObject().put("response_mime_type", "application/json"))
                if (Prefs.ground && !json) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
                val chain = (listOf(Prefs.model) + MODEL_FALLBACKS).distinct()
                var code = 0
                var txt = ""
                var used = chain[0]
                var firstCode = 0
                var firstErr = ""
                for ((idx, mdl) in chain.withIndex()) {
                    val c = URL("https://generativelanguage.googleapis.com/v1beta/models/" + mdl + ":generateContent")
                        .openConnection() as HttpURLConnection
                    c.requestMethod = "POST"
                    c.setRequestProperty("Content-Type", "application/json")
                    c.setRequestProperty("x-goog-api-key", key)
                    c.doOutput = true; c.connectTimeout = 30000; c.readTimeout = 180000
                    c.outputStream.use { it.write(body.toString().toByteArray()) }
                    code = c.responseCode
                    txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
                    used = mdl
                    if (code in 200..299) break
                    Logx.add("AI HTTP " + code + " model=" + mdl + " " + txt.take(160))
                    if (idx == 0) { firstCode = code; firstErr = "ERR $code ($mdl): " + txt.take(300) }
                    val retry = code == 404 || code == 429 || ((code == 400 || code == 403) && txt.contains("model", ignoreCase = true))
                    if (!retry) break
                }
                if (code !in 200..299) return@withContext firstErr.ifBlank { "ERR $code: " + txt.take(300) }
                if (used != chain[0] && firstCode == 404) Prefs.model = used
                val cands = JSONObject(txt).optJSONArray("candidates")
                if (cands == null || cands.length() == 0) return@withContext "ERR: AI ne jawab nahi diya (safety filter ya khali). Sawal thoda badal ke try karo."
                val cand = cands.getJSONObject(0)
                val r = cand.optJSONObject("content")?.optJSONArray("parts")
                    ?: return@withContext "ERR: AI ne khali jawab diya (" + cand.optString("finishReason") + "). Dobara try karo."
                var out = (0 until r.length()).joinToString("") { r.getJSONObject(it).optString("text") }
                out = Anon.unmask(out)
                if (!json) {
                    val src = cand.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
                    if (src != null && src.length() > 0) {
                        out += "\n\nSources:\n" + (0 until minOf(src.length(), 6)).joinToString("\n") { i ->
                            val w = src.getJSONObject(i).optJSONObject("web")
                            "- " + (w?.optString("title") ?: "") + " " + (w?.optString("uri") ?: "")
                        }
                    }
                    val cites = citeList(out)
                    if (cites.isNotEmpty()) out += "\n\n✅ Verify karo (cited): " + cites.joinToString(", ")
                }
                out
            } catch (e: Exception) {
                netFail = e is java.io.IOException
                Logx.add("AI: " + e.toString())
                "ERR: " + (e.message ?: e.toString())
            } finally { Anon.map = emptyMap() }
        }
}
