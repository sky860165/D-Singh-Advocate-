package com.dsingh.advocate

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

object Reminders {
    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    private fun pi(ctx: Context, key: String, t: String = "", m: String = ""): PendingIntent {
        val id = key.hashCode()
        return PendingIntent.getBroadcast(ctx, id,
            Intent(ctx, ReminderReceiver::class.java).putExtra("t", t).putExtra("m", m).putExtra("id", id), FLAGS)
    }

    private fun at8(d: LocalDate): Long = d.atTime(8, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    private fun am(ctx: Context) = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun arm(a: AlarmManager, t: Long, p: PendingIntent) {
        val exact = Build.VERSION.SDK_INT < 31 || a.canScheduleExactAlarms()
        if (exact) a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p)
        else a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p)
    }

    fun cancelTask(ctx: Context, c: Case, t: Todo) { am(ctx).cancel(pi(ctx, c.id + "t" + t.id)) }

    fun cancel(ctx: Context, c: Case) {
        listOf(0L, 1L).forEach { am(ctx).cancel(pi(ctx, c.id + it)) }
        c.tasks.forEach { cancelTask(ctx, c, it) }
    }

    fun scheduleAll(ctx: Context) {
        val a = am(ctx)
        val now = System.currentTimeMillis()
        for (c in Repo.cases) {
            val d = parseD(c.next)
            if (!c.active || d == null) {
                listOf(0L, 1L).forEach { a.cancel(pi(ctx, c.id + it)) }
            } else {
                for ((b, w) in listOf(1L to "Kal", 0L to "Aaj")) {
                    val t = at8(d.minusDays(b))
                    val p = pi(ctx, c.id + b, w + " hearing: " + c.title, c.court + " · " + c.no + " · " + c.client)
                    if (t > now) arm(a, t, p) else a.cancel(p)
                }
            }
            for (t in c.tasks) {
                val td = parseD(t.due)
                val p = pi(ctx, c.id + "t" + t.id, "Task: " + t.text, c.title)
                if (t.done || td == null || !c.active || at8(td) <= now) a.cancel(p)
                else arm(a, at8(td), p)
            }
        }
        val first = if (LocalTime.now().isBefore(LocalTime.of(8, 0))) LocalDate.now() else LocalDate.now().plusDays(1)
        a.setInexactRepeating(AlarmManager.RTC_WAKEUP, at8(first), AlarmManager.INTERVAL_DAY,
            PendingIntent.getBroadcast(ctx, 777, Intent(ctx, ReminderReceiver::class.java).putExtra("digest", true), FLAGS))
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        var t = i.getStringExtra("t")
        var m = i.getStringExtra("m")
        var id = i.getIntExtra("id", 0)
        if (i.getBooleanExtra("digest", false)) {
            Repo.init(c)
            HearingWidget.refresh(c)
            val td = today().toString()
            val h = Repo.cases.filter { it.active && it.next == td }
            val tk = Repo.cases.flatMap { cs -> cs.tasks.filter { !it.done && it.due == td } }
            if (h.isEmpty() && tk.isEmpty()) return
            t = "Aaj: " + h.size + " hearings, " + tk.size + " tasks"
            m = h.joinToString(", ") { it.title }.ifBlank { tk.joinToString(", ") { x -> x.text } }
            id = 777
        }
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("hearings", "Hearing reminders", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(c, "hearings")
            .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
            .setContentTitle(t).setContentText(m)
            .setContentIntent(open).setAutoCancel(true).build()
        nm.notify(id, n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Prefs.init(c); Repo.init(c); Reminders.scheduleAll(c)
    }
}
