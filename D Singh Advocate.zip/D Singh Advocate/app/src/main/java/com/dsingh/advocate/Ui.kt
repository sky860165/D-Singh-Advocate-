package com.dsingh.advocate

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONObject

// ------------------------------------------------------------ theme
val Gold = Color(0xFFE9B44C)
val Teal = Color(0xFF4FD1C5)
val Violet = Color(0xFF8B7CFF)
val Coral = Color(0xFFFF6B6B)
val Navy = Color(0xFF0A1020)
val Slate = Color(0xFF7C8DB5)

object ThemeState { var mode by mutableIntStateOf(1) }   // 0 auto, 1 dark, 2 light

object Lock {
    var unlocked by mutableStateOf(false)
    var busy = false
    var stopAt = 0L
}

private val DarkScheme = darkColorScheme(
    primary = Gold, onPrimary = Color(0xFF1B1300), primaryContainer = Color(0xFF3A2E12), onPrimaryContainer = Color(0xFFFFE3A6),
    secondary = Teal, onSecondary = Color(0xFF00201D), secondaryContainer = Color(0xFF3A2E12), onSecondaryContainer = Color(0xFFFFE3A6),
    tertiary = Violet, background = Navy, onBackground = Color(0xFFEAF0FF),
    surface = Color(0xFF0F1A30), onSurface = Color(0xFFEAF0FF), surfaceVariant = Color(0xFF1B2744), onSurfaceVariant = Color(0xFF9DB0D6),
    surfaceContainer = Color(0xFF141E36), surfaceContainerHigh = Color(0xFF18233F), surfaceContainerHighest = Color(0x8C1C2B4D),
    outline = Color(0xFF3A4A70), outlineVariant = Color(0x33FFFFFF), error = Coral
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF9A6A12), onPrimary = Color.White, primaryContainer = Color(0xFFFFE9BF), onPrimaryContainer = Color(0xFF3A2800),
    secondary = Color(0xFF0E8F86), secondaryContainer = Color(0xFFFFE9BF), onSecondaryContainer = Color(0xFF3A2800),
    tertiary = Color(0xFF5B4CE0), background = Color(0xFFF3F5FB), onBackground = Color(0xFF111827),
    surface = Color.White, onSurface = Color(0xFF111827), surfaceVariant = Color(0xFFE8ECF6), onSurfaceVariant = Color(0xFF4B5675),
    surfaceContainer = Color(0xFFEEF1F9), surfaceContainerHigh = Color(0xFFFFFFFF), surfaceContainerHighest = Color(0xE6FFFFFF),
    outline = Color(0xFFB8C0D8), outlineVariant = Color(0x1A000000), error = Color(0xFFC62828)
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(14.dp), small = RoundedCornerShape(16.dp), medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(28.dp), extraLarge = RoundedCornerShape(32.dp)
)

private val AppType = Typography(
    headlineLarge = TextStyle(fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.6).sp),
    headlineMedium = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.4).sp),
    headlineSmall = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.2).sp),
    titleLarge = TextStyle(fontSize = 19.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val sys = isSystemInDarkTheme()
    val dark = when (ThemeState.mode) { 0 -> sys; 2 -> false; else -> true }
    val ctx = LocalContext.current
    LaunchedEffect(dark) {
        val a = ctx as? ComponentActivity
        if (a != null) {
            val t = android.graphics.Color.TRANSPARENT
            if (dark) a.enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(t), navigationBarStyle = SystemBarStyle.dark(t))
            else a.enableEdgeToEdge(statusBarStyle = SystemBarStyle.light(t, t), navigationBarStyle = SystemBarStyle.light(t, t))
        }
    }
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, shapes = AppShapes, typography = AppType) {
        Backdrop(dark, content)
    }
}

@Composable
fun Backdrop(dark: Boolean, content: @Composable () -> Unit) {
    val bg = if (dark) listOf(Color(0xFF0A1020), Color(0xFF0E1830), Color(0xFF111F3D)) else listOf(Color(0xFFF6F8FD), Color(0xFFEEF2FB))
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(bg)).drawBehind {
        if (dark) {
            val c1 = Offset(size.width * 0.9f, size.height * 0.05f)
            drawCircle(Brush.radialGradient(listOf(Gold.copy(alpha = 0.16f), Color.Transparent), center = c1, radius = size.width * 0.8f), radius = size.width * 0.8f, center = c1)
            val c2 = Offset(size.width * 0.05f, size.height * 0.75f)
            drawCircle(Brush.radialGradient(listOf(Teal.copy(alpha = 0.10f), Color.Transparent), center = c2, radius = size.width * 0.9f), radius = size.width * 0.9f, center = c2)
        }
    }) {
        Surface(color = Color.Transparent, contentColor = MaterialTheme.colorScheme.onSurface, modifier = Modifier.fillMaxSize()) { content() }
    }
}

// ------------------------------------------------------------ shell
@Composable
fun App() { AppTheme { Gate() } }

@Composable
fun Gate() {
    val ctx = LocalContext.current
    val auth = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        Lock.busy = false
        if (r.resultCode == Activity.RESULT_OK) { Lock.stopAt = System.currentTimeMillis(); Lock.unlocked = true }
    }
    val launchAuth: () -> Unit = {
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val i = km.createConfirmDeviceCredentialIntent("D Singh Advocate", "Unlock karo")
        if (i == null) Lock.unlocked = true else { Lock.busy = true; auth.launch(i) }
    }
    if (Prefs.lock && !Lock.unlocked) {
        LaunchedEffect(Unit) { launchAuth() }
        LockScreen(launchAuth)
    } else Main()
}

@Composable
fun LockScreen(onUnlock: () -> Unit) {
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(contentAlignment = Alignment.Center) {
            Box(Modifier.size(180.dp).drawBehind { drawCircle(Brush.radialGradient(listOf(Gold.copy(alpha = 0.35f), Color.Transparent))) })
            Logo(96.dp)
        }
        Spacer(Modifier.height(20.dp))
        Text("D Singh Advocate", style = MaterialTheme.typography.headlineMedium)
        Text("Aapka smart legal workspace", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(28.dp))
        Button(onUnlock, shape = RoundedCornerShape(50)) { Text("🔒  Unlock", modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)) }
    }
}

@Composable
fun Main() {
    var tab by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<String?>(null) }
    val imeUp = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    BackHandler(open != null) { open = null }
    BackHandler(open == null && tab == 5) { tab = 0 }
    Scaffold(containerColor = Color.Transparent, contentColor = MaterialTheme.colorScheme.onSurface,
        bottomBar = { if (open == null && !imeUp) FloatingNav(tab) { tab = it } }) { p ->
        Column(Modifier.padding(p).fillMaxSize().imePadding()) {
            if (!Net.online) OfflineBanner()
            Box(Modifier.weight(1f)) {
            val o = open
            if (o != null) CaseScreen(o) { open = null } else Crossfade(targetState = tab, label = "tab") { t ->
                when (t) {
                    0 -> Home({ open = it }, { tab = 5 }, { tab = it })
                    1 -> Cases { open = it }
                    2 -> CalendarScreen { open = it }
                    3 -> AiScreen { open = it }
                    4 -> ToolsScreen()
                    else -> SettingsScreen()
                }
            }
            }
        }
    }
}

@Composable
fun FloatingNav(tab: Int, onTab: (Int) -> Unit) {
    val items = listOf(Triple("Home", Icons.Default.Home, 0), Triple("Cases", Icons.Default.List, 1), Triple("Calendar", Icons.Default.DateRange, 2),
        Triple("AI", Icons.Default.Star, 3), Triple("Tools", Icons.Default.Build, 4))
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Surface(shape = RoundedCornerShape(32.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), shadowElevation = 16.dp, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                items.forEach { (label, icon, i) ->
                    val sel = tab == i
                    val bg by animateColorAsState(if (sel) MaterialTheme.colorScheme.primary else Color.Transparent, label = "nav")
                    Row(Modifier.clip(RoundedCornerShape(26.dp)).background(bg).clickable { onTab(i) }
                        .padding(horizontal = if (sel) 16.dp else 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(icon, label, tint = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
                        AnimatedVisibility(visible = sel) {
                            Text(label, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.padding(start = 6.dp))
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------ small components
@Composable
fun Pill(text: String, c: Color) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = 0.16f)).border(1.dp, c.copy(alpha = 0.4f), RoundedCornerShape(50))
        .padding(horizontal = 10.dp, vertical = 3.dp)) {
        Text(text, color = c, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
fun Avatar(name: String, dia: Dp) {
    val ch = name.trim().firstOrNull()?.uppercase() ?: "?"
    val pal = listOf(Gold, Teal, Violet, Coral, Color(0xFF5AA9FF))
    val c = pal[kotlin.math.abs(name.hashCode() % pal.size)]
    Box(Modifier.size(dia).clip(CircleShape).background(Brush.linearGradient(listOf(c, c.copy(alpha = 0.55f)))), contentAlignment = Alignment.Center) {
        Text(ch, color = Navy, fontWeight = FontWeight.ExtraBold, fontSize = (dia.value * 0.42f).sp)
    }
}

@Composable
fun SectionTitle(t: String) {
    Text(t.uppercase(), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp))
}

@Composable
fun EmptyState(emoji: String, title: String, sub: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(emoji, fontSize = 44.sp)
        Spacer(Modifier.height(8.dp))
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

@Composable
fun Ring(p: Float, dia: Dp, label: String, color: Color = Gold, txt: Color = Color.White, track: Color = Color.White.copy(alpha = 0.12f)) {
    val a by animateFloatAsState(p, tween(1000), label = "ring")
    Box(Modifier.size(dia), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val s = 10.dp.toPx()
            val tl = Offset(s / 2, s / 2)
            val sz = Size(this.size.width - s, this.size.height - s)
            drawArc(track, -90f, 360f, false, tl, sz, style = Stroke(s, cap = StrokeCap.Round))
            drawArc(color, -90f, 360f * a, false, tl, sz, style = Stroke(s, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text((a * 100).toInt().toString() + "%", fontWeight = FontWeight.Bold, color = txt, fontSize = 18.sp)
            Text(label, fontSize = 10.sp, color = txt.copy(alpha = 0.7f))
        }
    }
}

@Composable
fun ActionChip(emoji: String, label: String, onClick: () -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.surfaceContainerHighest)
        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(50)).clickable(onClick = onClick)
        .padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(emoji); Spacer(Modifier.width(8.dp)); Text(label, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun StatBase(icon: String, label: String, value: String, c: Color, m: Modifier) {
    Box(m.clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(c.copy(alpha = 0.22f), c.copy(alpha = 0.06f))))
        .border(1.dp, c.copy(alpha = 0.35f), RoundedCornerShape(22.dp)).padding(16.dp)) {
        Column {
            Box(Modifier.size(34.dp).clip(CircleShape).background(c.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) { Text(icon) }
            Spacer(Modifier.height(10.dp))
            Text(value, style = MaterialTheme.typography.headlineSmall)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun StatTile(icon: String, label: String, n: Int, c: Color, m: Modifier) {
    val v by animateIntAsState(n, tween(900), label = "n")
    StatBase(icon, label, v.toString(), c, m)
}

@Composable
fun PulseDots() {
    val tr = rememberInfiniteTransition(label = "dots")
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(3) { i ->
            val a by tr.animateFloat(0.25f, 1f, infiniteRepeatable(tween(600, delayMillis = i * 150), RepeatMode.Reverse), label = "d" + i)
            Box(Modifier.size(9.dp).clip(CircleShape).background(Gold.copy(alpha = a)))
        }
        Spacer(Modifier.width(4.dp))
        Text("AI soch raha hai...", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ------------------------------------------------------------ cards
@Composable
fun CaseCard(c: Case, onClick: () -> Unit) {
    val d = dayDiff(c.next)
    val od = d != null && d < 0L && c.active
    val col = when { c.next.isBlank() || od -> Coral; d == 0L || d == 1L -> Gold; else -> Teal }
    val si = STAGES.indexOf(c.stage)
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(c.client.ifBlank { c.title }, 46.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(c.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(listOf(c.client, c.no).filter { it.isNotBlank() }.joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (si >= 0) {
                    LinearProgressIndicator(progress = { (si + 1f) / STAGES.size }, modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                        color = Teal, trackColor = MaterialTheme.colorScheme.outlineVariant)
                    Text(c.stage, style = MaterialTheme.typography.bodySmall, color = muted)
                }
                if (c.pending > 0 || !c.active) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (c.pending > 0) Pill("Baaki " + inr(c.pending), Gold)
                    if (!c.active) Pill("Disposed", Slate)
                }
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Pill(if (c.next.isBlank()) "Tareekh nahi" else rel(c.next), col)
                if (c.next.isNotBlank()) Text(fmtD(c.next) + dayNote(c.next), style = MaterialTheme.typography.bodySmall, color = muted, textAlign = TextAlign.End)
            }
        }
    }
}

fun LazyListScope.sec(t: String, l: List<Case>, open: (String) -> Unit) {
    if (l.isEmpty()) return
    item { SectionTitle(t) }
    items(l) { CaseCard(it) { open(it.id) } }
}

fun monthly(cs: List<Case>): List<Triple<String, Long, Long>> {
    val now = today().withDayOfMonth(1)
    return (5 downTo 0).map { k ->
        val m = now.minusMonths(k.toLong())
        val ym = m.toString().take(7)
        Triple(m.month.getDisplayName(java.time.format.TextStyle.SHORT, java.util.Locale.ENGLISH),
            cs.sumOf { c -> c.pays.filter { it.date.startsWith(ym) }.sumOf { it.amount } },
            cs.sumOf { c -> c.exps.filter { it.date.startsWith(ym) }.sumOf { it.amount } })
    }
}

@Composable
fun FlowChart() {
    val data = remember(Repo.cases) { monthly(Repo.cases) }
    val mx = (data.maxOfOrNull { maxOf(it.second, it.third) } ?: 0L).coerceAtLeast(1L)
    val t = remember { Animatable(0f) }
    LaunchedEffect(data) { t.snapTo(0f); t.animateTo(1f, tween(900)) }
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Card(Modifier.fillMaxWidth(), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
        Column(Modifier.padding(16.dp)) {
            Text("Kamai vs Kharcha (6 mahine)", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(8.dp).clip(CircleShape).background(Gold)); Spacer(Modifier.width(4.dp)); Text("Mili", style = MaterialTheme.typography.bodySmall, color = muted) }
                Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(8.dp).clip(CircleShape).background(Coral)); Spacer(Modifier.width(4.dp)); Text("Kharcha", style = MaterialTheme.typography.bodySmall, color = muted) }
            }
            Canvas(Modifier.fillMaxWidth().height(120.dp).padding(top = 8.dp)) {
                val gw = size.width / data.size
                val bw = gw * 0.28f
                val gap = 2.dp.toPx()
                data.forEachIndexed { i, d ->
                    val x = i * gw + gw / 2
                    val h1 = size.height * (d.second.toFloat() / mx) * t.value
                    val h2 = size.height * (d.third.toFloat() / mx) * t.value
                    drawRoundRect(Gold, Offset(x - bw - gap, size.height - h1), Size(bw, h1), CornerRadius(6.dp.toPx()))
                    drawRoundRect(Coral, Offset(x + gap, size.height - h2), Size(bw, h2), CornerRadius(6.dp.toPx()))
                }
            }
            Row(Modifier.fillMaxWidth()) {
                data.forEach { Text(it.first, Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall, color = muted) }
            }
        }
    }
}

@Composable
fun FeeSummary(c: Case, spent: Long) {
    val p = if (c.fee > 0) (c.paid.toFloat() / c.fee).coerceIn(0f, 1f) else 0f
    Card(Modifier.fillMaxWidth(), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Ring(p, 96.dp, "Mili", Gold, MaterialTheme.colorScheme.onSurface, MaterialTheme.colorScheme.outlineVariant)
            Spacer(Modifier.width(16.dp))
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Total " + inr(c.fee))
                Text("Mili " + inr(c.paid), color = Teal)
                Text("Baaki " + inr(c.pending), fontWeight = FontWeight.Bold, color = Gold)
                Text("Kharcha " + inr(spent) + " · Net " + inr(c.paid - spent), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// ------------------------------------------------------------ home
@Composable
fun Home(open: (String) -> Unit, goSet: () -> Unit, goTab: (Int) -> Unit) {
    val all = Repo.cases
    val act = all.filter { it.active }
    val td = today().toString()
    val hs = act.filter { it.next == td }
    val wk = act.filter { (dayDiff(it.next) ?: -1L) in 0L..7L }.sortedBy { it.next }
    val od = act.filter { (dayDiff(it.next) ?: 0L) < 0L }
    val nd = act.filter { it.next.isBlank() }
    val fees = act.filter { it.pending > 0 }.sortedByDescending { it.pending }.take(5)
    val tk = act.flatMap { cs -> cs.tasks.filter { !it.done && (dayDiff(it.due) ?: 99L) <= 2L }.map { cs to it } }
    val totalFee = all.sumOf { it.fee }
    val recovery = if (totalFee > 0) (all.sumOf { it.paid }.toFloat() / totalFee).coerceIn(0f, 1f) else 0f
    var addDlg by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            val days = listOf("Somwar", "Mangalwar", "Budhwar", "Guruwar", "Shukrawar", "Shaniwar", "Raviwar")
            val d = today()
            Row(verticalAlignment = Alignment.CenterVertically) {
                Logo(46.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(days[d.dayOfWeek.value - 1] + " · " + fmtD(d.toString()), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(if (Prefs.name.isBlank()) "D Singh Advocate" else "Adv. " + Prefs.name, style = MaterialTheme.typography.headlineSmall)
                }
                IconButton(goSet) { Icon(Icons.Default.Settings, "settings") }
            }
        }
        item {
            val shape = RoundedCornerShape(28.dp)
            Box(Modifier.fillMaxWidth().clip(shape).background(Brush.linearGradient(listOf(Color(0xFF1E2B52), Color(0xFF2B2160))))
                .border(1.dp, Color.White.copy(alpha = 0.10f), shape).padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("AAJ KI HEARINGS", style = MaterialTheme.typography.titleSmall, color = Gold)
                        val n by animateIntAsState(hs.size, tween(800), label = "hs")
                        Text(n.toString(), fontSize = 52.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text(if (hs.isEmpty()) "Aaj koi hearing nahi 🎉" else hs.take(2).joinToString(" · ") { it.title }, color = Color.White.copy(alpha = 0.85f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                        val nx = wk.firstOrNull { it.next != td }
                        if (nx != null) Text("Agli: " + nx.title + " · " + rel(nx.next), style = MaterialTheme.typography.bodySmall, color = Teal, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Ring(recovery, 96.dp, "Recovery")
                }
            }
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                item { ActionChip("＋", "Naya case") { addDlg = true } }
                item { ActionChip("🎤", "Voice update") { goTab(3) } }
                item { ActionChip("📝", "AI draft") { goTab(3) } }
                item { ActionChip("📅", "Calendar") { goTab(2) } }
                item { ActionChip("🏞", "Zameen") { ToolNav.land = true; goTab(4) } }
                item { ActionChip("🧰", "Tools") { goTab(4) } }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatTile("📁", "Active cases", act.size, Teal, Modifier.weight(1f))
                    StatTile("📅", "Is hafte hearings", wk.size, Violet, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatBase("💰", "Fees baaki", inr(all.sumOf { it.pending }), Gold, Modifier.weight(1f))
                    StatTile("✅", "Disposed", all.count { !it.active }, Slate, Modifier.weight(1f))
                }
            }
        }
        item { FlowChart() }
        if (all.isEmpty()) item { EmptyState("⚖", "Shuru karte hain", "＋ Naya case dabake pehla case add karo.\nSettings me Gemini key daalo to AI chalu hoga.") }
        sec("⚠ Tareekh nikal gayi, update karo", od, open)
        sec("Agle 7 din ki hearings", wk, open)
        sec("Bina tareekh ke cases", nd, open)
        sec("Sabse zyada fees baaki", fees, open)
        if (tk.isNotEmpty()) {
            item { SectionTitle("Urgent tasks") }
            items(tk) { (cs, t) ->
                Card(Modifier.fillMaxWidth().clickable { open(cs.id) }, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(t.text, style = MaterialTheme.typography.titleMedium)
                            Text(cs.title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Pill(rel(t.due), if ((dayDiff(t.due) ?: 0L) < 0L) Coral else Gold)
                    }
                }
            }
        }
    }
    if (addDlg) CaseDialog(null) { addDlg = false }
}

// ------------------------------------------------------------ calendar
@Composable
fun CalendarScreen(open: (String) -> Unit) {
    val act = Repo.cases.filter { it.active }
    var sel by remember { mutableStateOf<String?>(null) }
    val days = (0..13).map { today().plusDays(it.toLong()) }
    val dn = listOf("Som", "Mang", "Budh", "Guru", "Shuk", "Shani", "Ravi")
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Calendar", style = MaterialTheme.typography.headlineMedium)
            Text("Agle 14 din. Din chuno to sirf usi din ki hearings dikhengi.", style = MaterialTheme.typography.bodySmall, color = muted)
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(days) { d ->
                    val iso = d.toString()
                    val n = act.count { it.next == iso }
                    val on = sel == iso
                    val fg = if (on) Navy else MaterialTheme.colorScheme.onSurface
                    Column(Modifier.clip(RoundedCornerShape(20.dp)).background(if (on) Gold else MaterialTheme.colorScheme.surfaceContainerHighest)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(20.dp))
                        .clickable { sel = if (on) null else iso }.padding(horizontal = 14.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(dn[d.dayOfWeek.value - 1], fontSize = 11.sp, color = if (on) Navy else muted)
                        Text(d.dayOfMonth.toString(), fontWeight = FontWeight.Bold, fontSize = 20.sp, color = fg)
                        Box(Modifier.size(6.dp).clip(CircleShape).background(if (n > 0) (if (on) Navy else Gold) else Color.Transparent))
                    }
                }
            }
        }
        val list = act.filter { it.next.isNotBlank() && (sel == null || it.next == sel) }.sortedBy { it.next }
        if (list.isEmpty()) item { EmptyState("📅", "Koi hearing nahi", "Is din ya is samay koi hearing scheduled nahi hai.") }
        list.groupBy { it.next }.forEach { (d, cs) ->
            item {
                Text(fmtD(d) + " · " + rel(d) + dayNote(d), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp),
                    color = if ((dayDiff(d) ?: 0L) < 0L) Coral else MaterialTheme.colorScheme.primary)
            }
            items(cs) { CaseCard(it) { open(it.id) } }
        }
        if (sel == null) sec("Bina tareekh ke (pending)", act.filter { it.next.isBlank() }, open)
    }
}

// ------------------------------------------------------------ case screen
@Composable
fun HeroStat(l: String, v: String, m: Modifier) {
    Column(m.clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.08f)).padding(10.dp)) {
        Text(l, fontSize = 10.sp, color = Color.White.copy(alpha = 0.65f))
        Text(v, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
    }
}

@Composable
fun HeroBtn(t: String, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.14f)).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 9.dp)) {
        Text(t, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun TabPill(t: String, on: Boolean, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(if (on) Gold else MaterialTheme.colorScheme.surfaceContainerHighest)
        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(50)).clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 9.dp)) {
        Text(t, color = if (on) Navy else MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun CaseScreen(id: String, close: () -> Unit) {
    val c = Repo.cases.find { it.id == id }
    if (c == null) { LaunchedEffect(Unit) { close() }; return }
    var tab by remember { mutableIntStateOf(0) }
    var edit by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val tabs = listOf("Details", "Hearings", "Fees", "Tasks", "Docs", "Client", "AI")
    val shape = RoundedCornerShape(28.dp)
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(close) { Icon(Icons.Default.ArrowBack, "back") }
            Spacer(Modifier.weight(1f))
            IconButton({ edit = true }) { Icon(Icons.Default.Edit, "edit") }
        }
        Box(Modifier.padding(horizontal = 16.dp).fillMaxWidth().clip(shape).background(Brush.linearGradient(listOf(Color(0xFF1E2B52), Color(0xFF2B2160))))
            .border(1.dp, Color.White.copy(alpha = 0.10f), shape).padding(18.dp)) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(c.client.ifBlank { c.title }, 52.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.title, color = Color.White, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(listOf(c.no, c.court).filter { it.isNotBlank() }.joinToString(" · "), color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HeroStat("Agli tareekh", if (c.next.isBlank()) "—" else rel(c.next), Modifier.weight(1f))
                    HeroStat("Baaki fees", inr(c.pending), Modifier.weight(1f))
                    HeroStat("Stage", c.stage.ifBlank { "—" }, Modifier.weight(1f))
                }
                if (c.phone.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        HeroBtn("📞 Call") { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + c.phone))) }
                        HeroBtn("💬 WhatsApp") { ctx.wa(c.phone, reminderMsg(c)) }
                    }
                }
            }
        }
        LazyRow(Modifier.padding(vertical = 10.dp), contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(tabs) { i, t -> TabPill(t, tab == i) { tab = i } }
        }
        Box(Modifier.weight(1f)) {
            when (tab) { 0 -> Details(c); 1 -> Hearings(c); 2 -> Fees(c); 3 -> TasksTab(c); 4 -> DocsTab(c); 5 -> Comms(c); else -> CaseAi(c) }
        }
    }
    if (edit) CaseDialog(c) { edit = false }
}

// ------------------------------------------------------------ AI screen
@Composable
fun SegBtn(label: String, on: Boolean, m: Modifier, onClick: () -> Unit) {
    Box(m.clip(RoundedCornerShape(50)).background(if (on) Gold else Color.Transparent).clickable(onClick = onClick).padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
        Text(label, color = if (on) Navy else MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun AiScreen(open: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var mode by remember { mutableIntStateOf(0) }
    var inp by remember { mutableStateOf("") }
    var out by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var opened by remember { mutableStateOf<String?>(null) }
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val sugg = listOf("Legal notice ka draft banao", "Bail application ka draft", "BNS ki dhara samjhao", "Judgment ka summary nikalo", "Cheque bounce ka notice")
    var chooser by remember { mutableStateOf<LocalParse.Result?>(null) }
    val send: () -> Unit = {
        if (inp.isNotBlank()) {
            opened = null; chooser = null
            if (mode == 0) scope.launch { busy = true; out = Ai.ask(inp); busy = false }
            else {
                val lp = LocalParse.parse(inp, Repo.cases.filter { it.active })
                val nx = lp.date
                if (nx != null && lp.matched && lp.cases.size == 1) {
                    val cs = lp.cases[0]
                    applyHearing(cs, nx, "Voice/text update")
                    opened = cs.id
                    out = "✅ " + cs.title + "\nAgli hearing: " + fmtD(nx) + " (reminder set, bina internet ke)"
                } else if (nx != null) {
                    chooser = lp; out = ""
                } else if (Net.online) scope.launch {
                    busy = true
                    val list = Repo.cases.filter { it.active }.joinToString("\n") { it.id + "|" + it.title + "|" + it.client }
                    val r = Ai.ask("Aaj ki date " + today() + ".\nCases (id|title|client):\n" + list + "\n\nAdvocate ne kaha: \"" + inp +
                        "\"\nSahi case dhundo aur sirf JSON do: {\"id\":\"case id ya khali\",\"next\":\"YYYY-MM-DD ya khali\",\"note\":\"hearing me kya hua ya khali\"}. Agar saal nahi bola to aane wali agli date lo.",
                        system = "", json = true)
                    out = if (r.startsWith("ERR")) r else try {
                        val j = JSONObject(r.trim())
                        val cs = Repo.cases.find { it.id == j.optString("id") }
                        val nd = j.optString("next").let { if (parseD(it) != null) it else "" }
                        if (cs == null) "Case match nahi hua. Client ya case ka naam saaf bolo." else {
                            val nt = j.optString("note")
                            Repo.upsert(cs.copy(next = if (nd.isNotBlank()) nd else cs.next,
                                hearings = if (nd.isNotBlank() || nt.isNotBlank()) cs.hearings + Hearing(today().toString(), nt, nd) else cs.hearings))
                            opened = cs.id
                            "✅ " + cs.title + (if (nd.isNotBlank()) "\nAgli hearing: " + fmtD(nd) + " (reminder set)" else "") + (if (nt.isNotBlank()) "\nNote: " + nt else "")
                        }
                    } catch (e: Exception) { "ERR: AI ka jawab samajh nahi aaya, dobara try karo." }
                    busy = false
                } else out = "📴 Tareekh samajh nahi aayi. Aise likho: \"Ram Kumar 15/12\" ya \"Ram Kumar 15 December\"."
            }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Gold, Violet))), contentAlignment = Alignment.Center) {
                Text("✦", fontSize = 22.sp, color = Navy)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("AI Assistant", style = MaterialTheme.typography.headlineSmall)
                Text(if (Prefs.key.isBlank()) "⚠ Settings me Gemini key daalo" else "Gemini · " + Prefs.model + (if (Prefs.ground) " · Search ON" else ""),
                    style = MaterialTheme.typography.bodySmall, color = if (Prefs.key.isBlank()) Coral else muted)
            }
        }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.surfaceContainerHighest).padding(4.dp)) {
            SegBtn("Sawal / Draft", mode == 0, Modifier.weight(1f)) { mode = 0; out = "" }
            SegBtn("🎤 Hearing update", mode == 1, Modifier.weight(1f)) { mode = 1; out = "" }
        }
        if (mode == 0) LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(sugg) { s -> ActionChip("✦", s) { inp = s } } }
        else Text("Bolo: \"Ram Kumar ke case ki agli hearing 15 December ko hai\". Case aur tareekh apne aap update hogi." +
            (if (Prefs.anon) "\n⚠ Is mode me case/client ke naam AI ko jaate hain (naam chhupana yahan lagu nahi)." else ""),
            style = MaterialTheme.typography.bodySmall, color = muted)
        Card(Modifier.fillMaxWidth(), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
            Column(Modifier.padding(12.dp)) {
                OutlinedTextField(inp, { inp = it }, Modifier.fillMaxWidth(), minLines = 3,
                    placeholder = { Text(if (mode == 0) "Hindi me likho ya bolo..." else "Ram Kumar ke case ki agli hearing 15 December ko hai") })
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    MicButton(lang = if (mode == 1) "en-IN" else "hi-IN") { inp = (inp + " " + it).trim() }
                    Spacer(Modifier.weight(1f))
                    val ok = !busy && inp.isNotBlank()
                    Row(Modifier.alpha(if (ok) 1f else 0.5f).clip(RoundedCornerShape(50)).background(Brush.linearGradient(listOf(Gold, Color(0xFFFFD27A))))
                        .clickable(enabled = ok, onClick = send).padding(horizontal = 20.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Send, null, tint = Navy)
                        Spacer(Modifier.width(8.dp))
                        Text(if (mode == 0) "Bhejo" else "Update karo", color = Navy, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        if (busy) PulseDots()
        if (out.isNotBlank()) OutBox(out)
        chooser?.let { ch ->
            Card(Modifier.fillMaxWidth(), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Kaunsa case? (agli tareekh " + fmtD(ch.date ?: "") + ")", fontWeight = FontWeight.Bold)
                    ch.cases.forEach { cs ->
                        TextButton({
                            applyHearing(cs, ch.date ?: "", "Voice/text update")
                            opened = cs.id; chooser = null
                            out = "✅ " + cs.title + "\nAgli hearing: " + fmtD(ch.date ?: "") + " (reminder set)"
                        }) { Text(cs.title + " · " + cs.client) }
                    }
                }
            }
        }
        opened?.let { id -> OutlinedButton({ open(id) }) { Text("Case kholo") } }
        if (AiQueue.items.isNotEmpty()) {
            SectionTitle("AI Inbox")
            AiQueue.items.reversed().forEach { q -> InboxCard(q) }
        }
    }
}

@Composable
fun OfflineBanner() {
    Row(Modifier.fillMaxWidth().background(Gold.copy(alpha = 0.16f)).padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("📴", fontSize = 14.sp)
        Spacer(Modifier.width(8.dp))
        Text("Offline mode: sab kuch chalega, AI requests queue me jayengi.", style = MaterialTheme.typography.bodySmall, color = Gold)
    }
}

@Composable
fun InboxCard(q: QItem) {
    var show by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val col = when (q.status) { "done" -> Teal; "failed" -> Coral; else -> Gold }
    Card(Modifier.fillMaxWidth().clickable { show = !show }, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(q.label, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(fmtD(q.created), style = MaterialTheme.typography.bodySmall, color = muted)
                }
                Pill(when (q.status) { "done" -> "Taiyar ✅"; "failed" -> "Fail ⚠"; else -> "Pending ⏳" }, col)
                IconButton({ AiQueue.delete(q.id) }) { Icon(Icons.Default.Delete, "del") }
            }
            if (q.status == "pending") {
                Text(if (Net.online) "Net hai, abhi chalega." else "Net aate hi apne aap chalega.", style = MaterialTheme.typography.bodySmall, color = muted)
                if (Net.online) TextButton({ AiQueue.process(ctx) }) { Text("Abhi chalao") }
            }
            if (show && q.result.isNotBlank()) OutBox(q.result, q.label)
        }
    }
}
