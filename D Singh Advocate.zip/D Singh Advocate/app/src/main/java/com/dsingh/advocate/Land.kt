package com.dsingh.advocate

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

object ToolNav { var land by mutableStateOf(false) }

fun num(s: String): Double = s.replace(",", "").trim().toDoubleOrNull() ?: 0.0

fun inrIN(x: Double): String {
    val neg = x < 0
    var s = Math.round(Math.abs(x)).toString()
    if (s.length > 3) {
        val last3 = s.takeLast(3)
        var rest = s.dropLast(3)
        val sb = StringBuilder()
        while (rest.length > 2) { sb.insert(0, "," + rest.takeLast(2)); rest = rest.dropLast(2) }
        s = rest + sb.toString() + "," + last3
    }
    return (if (neg) "-" else "") + "₹" + s
}

fun inrShort(x: Double): String = when {
    Math.abs(x) >= 1e7 -> "%.2f Crore".format(Locale.US, x / 1e7)
    Math.abs(x) >= 1e5 -> "%.2f Lakh".format(Locale.US, x / 1e5)
    else -> ""
}

object Land {
    val LEN = listOf("Feet" to 1.0, "Meter" to 3.280839895, "Gaj (yard)" to 3.0, "Inch" to 1.0 / 12.0)
    val AREA = listOf("sq ft" to 1.0, "sq m" to 10.76391042, "gaj (sq yd)" to 9.0, "decimal/cent" to 435.6, "guntha" to 1089.0,
        "kanal" to 5445.0, "marla" to 272.25, "acre" to 43560.0, "hectare" to 107639.1042)

    fun heron(a: Double, b: Double, c: Double): Double? {
        if (a <= 0 || b <= 0 || c <= 0) return null
        val s = (a + b + c) / 2
        val x = s * (s - a) * (s - b) * (s - c)
        return if (x > 0) Math.sqrt(x) else null
    }

    fun quadAvg(a: Double, b: Double, c: Double, d: Double): Double = ((a + c) / 2) * ((b + d) / 2)

    fun brahmagupta(a: Double, b: Double, c: Double, d: Double): Double? {
        if (a <= 0 || b <= 0 || c <= 0 || d <= 0) return null
        val s = (a + b + c + d) / 2
        val x = (s - a) * (s - b) * (s - c) * (s - d)
        return if (x > 0) Math.sqrt(x) else null
    }

    fun quadDiag(a: Double, b: Double, c: Double, d: Double, e: Double): Double? {
        val t1 = heron(a, b, e)
        val t2 = heron(c, d, e)
        return if (t1 != null && t2 != null) t1 + t2 else null
    }

    data class In(val areaSqft: Double, val rateUnitSqft: Double, val rate: Double, val circle: Double, val basis: Int,
                  val stampPct: Double, val surPct: Double, val regPct: Double, val regMax: Double,
                  val roadMode: Int, val roadVal: Double, val frontFt: Double, val brokPct: Double, val other: Double)

    data class Out(val deal: Double, val circle: Double, val base: Double, val stamp: Double, val sur: Double, val reg: Double,
                   val road: Double, val brok: Double, val other: Double, val charges: Double, val total: Double)

    fun compute(i: In): Out {
        val units = if (i.rateUnitSqft > 0) i.areaSqft / i.rateUnitSqft else 0.0
        val deal = units * i.rate
        val circle = units * i.circle
        val base = when (i.basis) {
            0 -> if (circle > 0) maxOf(deal, circle) else deal
            1 -> if (circle > 0) circle else deal
            else -> deal
        }
        val stamp = base * i.stampPct / 100.0
        val sur = stamp * i.surPct / 100.0
        var reg = base * i.regPct / 100.0
        if (i.regMax > 0) reg = minOf(reg, i.regMax)
        val road = when (i.roadMode) {
            0 -> deal * i.roadVal / 100.0
            1 -> i.roadVal * i.frontFt
            2 -> i.roadVal * i.areaSqft
            else -> i.roadVal
        }
        val brok = deal * i.brokPct / 100.0
        val charges = stamp + sur + reg + road + brok + i.other
        return Out(deal, circle, base, stamp, sur, reg, road, brok, i.other, charges, deal + charges)
    }
}

data class LandPreset(val name: String, val stamp: String, val stampW: String, val sur: String, val reg: String, val regMax: String)

object LandPresets {
    var list by mutableStateOf(listOf<LandPreset>())
    private lateinit var ctx: Context
    private fun f() = File(ctx.filesDir, "landpresets.json")
    fun init(c: Context) {
        ctx = c.applicationContext
        try {
            val a = JSONArray(f().readText())
            list = (0 until a.length()).map {
                val o = a.getJSONObject(it)
                LandPreset(o.optString("n"), o.optString("s"), o.optString("w"), o.optString("c"), o.optString("r"), o.optString("m"))
            }
        } catch (e: Exception) { }
    }
    private fun save() {
        try {
            f().writeText(JSONArray(list.map {
                JSONObject().put("n", it.name).put("s", it.stamp).put("w", it.stampW).put("c", it.sur).put("r", it.reg).put("m", it.regMax)
            }).toString())
        } catch (e: Exception) { }
    }
    fun upsert(p: LandPreset) {
        list = if (list.any { it.name == p.name }) list.map { if (it.name == p.name) p else it } else list + p
        save()
    }
    fun delete(name: String) { list = list.filter { it.name != name }; save() }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChipRow(opts: List<String>, sel: Int, onSel: (Int) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        opts.forEachIndexed { i, o -> FilterChip(sel == i, { onSel(i) }, { Text(o) }) }
    }
}

@Composable
fun Line(l: String, v: String, bold: Boolean = false) {
    val w = if (bold) FontWeight.Bold else FontWeight.Normal
    Row(Modifier.fillMaxWidth()) {
        Text(l, Modifier.weight(1f), fontWeight = w)
        Text(v, fontWeight = w)
    }
}

@Composable
fun LandCalc(onBack: () -> Unit) {
    BackHandler { onBack() }
    var mode by remember { mutableIntStateOf(0) }
    var lenU by remember { mutableIntStateOf(0) }
    var f1 by remember { mutableStateOf("") }
    var f2 by remember { mutableStateOf("") }
    var f3 by remember { mutableStateOf("") }
    var f4 by remember { mutableStateOf("") }
    var diag by remember { mutableStateOf("") }
    var directVal by remember { mutableStateOf("") }
    var directU by remember { mutableIntStateOf(0) }
    var customName by remember { mutableStateOf("") }
    var customSqft by remember { mutableStateOf("") }
    var rateU by remember { mutableIntStateOf(0) }
    var rate by remember { mutableStateOf("") }
    var circle by remember { mutableStateOf("") }
    var basis by remember { mutableIntStateOf(0) }
    var buyer by remember { mutableIntStateOf(0) }
    var stampPct by remember { mutableStateOf("") }
    var stampW by remember { mutableStateOf("") }
    var surPct by remember { mutableStateOf("") }
    var regPct by remember { mutableStateOf("") }
    var regMax by remember { mutableStateOf("") }
    var roadMode by remember { mutableIntStateOf(0) }
    var roadVal by remember { mutableStateOf("") }
    var frontLen by remember { mutableStateOf("") }
    var brokPct by remember { mutableStateOf("") }
    var other by remember { mutableStateOf("") }
    var presetName by remember { mutableStateOf("") }

    val lf = Land.LEN[lenU].second
    val customSq = num(customSqft)
    fun unitSq(i: Int): Double = if (i < Land.AREA.size) Land.AREA[i].second else customSq
    fun unitName(i: Int): String = if (i < Land.AREA.size) Land.AREA[i].first else customName.ifBlank { "local unit" }
    val unitNames = Land.AREA.map { it.first } + listOf(customName.ifBlank { "Local unit" })

    val (areaSqft, note) = when (mode) {
        0 -> Pair(num(f1) * lf * num(f2) * lf, "Lambai × chaudai")
        1 -> {
            val a = num(f1) * lf; val b = num(f2) * lf; val c = num(f3) * lf; val d = num(f4) * lf; val e = num(diag) * lf
            if (e > 0) {
                val r = Land.quadDiag(a, b, c, d, e)
                if (r == null) Pair(0.0, "⚠ Diagonal aur bhujaon se do triangle nahi ban rahe, naap check karo")
                else Pair(r, "Diagonal ke saath do triangle jodkar (sahi tareeka)")
            } else Pair(Land.quadAvg(a, b, c, d), "Sirf chaaron bhuja se andaaza: aamne-saamne ki bhujaon ka average × average. Tedhi zameen me asli area alag ho sakta hai; diagonal naap lo to sahi aayega.")
        }
        2 -> {
            val r = Land.heron(num(f1) * lf, num(f2) * lf, num(f3) * lf)
            if (r == null) Pair(0.0, "⚠ In teen bhujaon se triangle nahi banta") else Pair(r, "Teen bhuja (Heron formula)")
        }
        else -> Pair(num(directVal) * unitSq(directU), "Seedha diya hua area")
    }
    val maxArea = if (mode == 1 && num(diag) <= 0) Land.brahmagupta(num(f1) * lf, num(f2) * lf, num(f3) * lf, num(f4) * lf) else null
    val stampUse = if (buyer == 1 && num(stampW) > 0) num(stampW) else num(stampPct)
    val out = Land.compute(Land.In(areaSqft, unitSq(rateU), num(rate), num(circle), basis, stampUse, num(surPct), num(regPct), num(regMax),
        roadMode, num(roadVal), num(frontLen) * lf, num(brokPct), num(other)))

    fun areaLines(): String {
        val sb = StringBuilder()
        Land.AREA.forEach { sb.append("  " + it.first + ": " + "%,.3f".format(Locale.US, areaSqft / it.second) + "\n") }
        if (customSq > 0) sb.append("  " + unitName(Land.AREA.size) + ": " + "%,.3f".format(Locale.US, areaSqft / customSq) + "\n")
        return sb.toString()
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Default.ArrowBack, "back") }
            Column {
                Text("Zameen Calculator", style = MaterialTheme.typography.headlineSmall)
                Text("Area · maaliyat · stamp duty · road tax", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        ToolCard("1. Zameen ka naap (area)") {
            ChipRow(listOf("Lambai × Chaudai", "Chaaron bhuja", "Teen bhuja", "Seedha area"), mode) { mode = it }
            if (mode != 3) {
                Text("Lambai ki ikai", style = MaterialTheme.typography.bodySmall)
                ChipRow(Land.LEN.map { it.first }, lenU) { lenU = it }
            }
            when (mode) {
                0 -> {
                    F("Lambai (length)", f1, KeyboardType.Decimal) { f1 = it }
                    F("Chaudai (width)", f2, KeyboardType.Decimal) { f2 = it }
                }
                1 -> {
                    F("Bhuja A (jaise road ki taraf)", f1, KeyboardType.Decimal) { f1 = it }
                    F("Bhuja B (agli bhuja)", f2, KeyboardType.Decimal) { f2 = it }
                    F("Bhuja C (A ke saamne)", f3, KeyboardType.Decimal) { f3 = it }
                    F("Bhuja D (B ke saamne)", f4, KeyboardType.Decimal) { f4 = it }
                    F("Diagonal (optional, sahi area ke liye)", diag, KeyboardType.Decimal) { diag = it }
                    Text("Bhuja A, B, C, D zameen ke charon taraf ghoomte hue lo. Diagonal wo seedhi lakeer hai jo A aur D ke milan wale kone se B aur C ke milan wale kone tak jaati hai.", style = MaterialTheme.typography.bodySmall)
                }
                2 -> {
                    F("Bhuja 1", f1, KeyboardType.Decimal) { f1 = it }
                    F("Bhuja 2", f2, KeyboardType.Decimal) { f2 = it }
                    F("Bhuja 3", f3, KeyboardType.Decimal) { f3 = it }
                }
                else -> {
                    F("Area", directVal, KeyboardType.Decimal) { directVal = it }
                    ChipRow(unitNames, directU) { directU = it }
                }
            }
            F("Local ikai ka naam (Bigha/Biswa/Katha...)", customName) { customName = it }
            F("1 local ikai = kitne sq ft", customSqft, KeyboardType.Decimal) { customSqft = it }
            Text("Bigha, biswa, katha ka maap state aur zile ke hisaab se alag hota hai. Apne tehsil/patwari ka maap yahan daalo.", style = MaterialTheme.typography.bodySmall)
        }

        if (areaSqft > 0) ToolCard("Area (sab ikai me)") {
            Text(note, style = MaterialTheme.typography.bodySmall)
            Land.AREA.forEach { Line(it.first, "%,.3f".format(Locale.US, areaSqft / it.second), it.first == "sq ft") }
            if (customSq > 0) Line(unitName(Land.AREA.size), "%,.3f".format(Locale.US, areaSqft / customSq))
            if (maxArea != null) Text("Is naap par zyada se zyada sambhav area: " + "%,.1f".format(Locale.US, maxArea) + " sq ft (asli area isse zyada nahi ho sakta).", style = MaterialTheme.typography.bodySmall)
        } else if (note.startsWith("⚠")) Text(note, color = MaterialTheme.colorScheme.error)

        ToolCard("2. Rate aur zameen ki maaliyat") {
            Text("Rate kis ikai me?", style = MaterialTheme.typography.bodySmall)
            ChipRow(unitNames, rateU) { rateU = it }
            F("Bazaar/deal rate (₹ per " + unitName(rateU) + ")", rate, KeyboardType.Decimal) { rate = it }
            F("Circle rate / sarkari rate (₹ per " + unitName(rateU) + ", optional)", circle, KeyboardType.Decimal) { circle = it }
        }

        ToolCard("3. Stamp duty aur registration") {
            Text("Stamp duty kis maaliyat par lagegi?", style = MaterialTheme.typography.bodySmall)
            ChipRow(listOf("Dono me se zyada", "Circle rate", "Deal value"), basis) { basis = it }
            Text("Kharidar", style = MaterialTheme.typography.bodySmall)
            ChipRow(listOf("Purush / Anya", "Mahila"), buyer) { buyer = it }
            F("Stamp duty % (general)", stampPct, KeyboardType.Decimal) { stampPct = it }
            F("Stamp duty % (mahila, agar alag ho)", stampW, KeyboardType.Decimal) { stampW = it }
            F("Surcharge / cess (stamp duty ka %)", surPct, KeyboardType.Decimal) { surPct = it }
            F("Registration fee %", regPct, KeyboardType.Decimal) { regPct = it }
            F("Registration fee ki seema ₹ (agar ho)", regMax, KeyboardType.Decimal) { regMax = it }
            Text("Ye rates state, shehar/gaanv, zameen ke type aur kharidar par depend karte hain aur badalte rehte hain. Sub-registrar office ya state ki official site se confirm karke daalo.", style = MaterialTheme.typography.bodySmall)
        }

        ToolCard("4. Road side tax / charge") {
            ChipRow(listOf("% maaliyat ka", "₹ per foot (road-facing)", "₹ per sq ft", "Flat ₹"), roadMode) { roadMode = it }
            F(when (roadMode) { 0 -> "Road charge (% of deal value)"; 1 -> "₹ per foot"; 2 -> "₹ per sq ft"; else -> "Flat amount ₹" }, roadVal, KeyboardType.Decimal) { roadVal = it }
            if (roadMode == 1) F("Road-facing lambai (upar chuni hui ikai me)", frontLen, KeyboardType.Decimal) { frontLen = it }
            Text("Road-facing plot par lagne wala road/development/PLC charge. Apni authority ya society ka rate daalo.", style = MaterialTheme.typography.bodySmall)
        }

        ToolCard("5. Anya kharch") {
            F("Dalali / brokerage (deal value ka %)", brokPct, KeyboardType.Decimal) { brokPct = it }
            F("Baaki kharch ₹ (vakeel, document, naqsha...)", other, KeyboardType.Decimal) { other = it }
        }

        ToolCard("Rate preset (apne state ke)") {
            F("Preset ka naam (jaise UP-Shehari-Purush)", presetName) { presetName = it }
            Button({
                if (presetName.isNotBlank()) LandPresets.upsert(LandPreset(presetName.trim(), stampPct, stampW, surPct, regPct, regMax))
            }) { Text("Ye stamp/registration rates save karo") }
            LandPresets.list.forEach { p ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton({ stampPct = p.stamp; stampW = p.stampW; surPct = p.sur; regPct = p.reg; regMax = p.regMax }, Modifier.weight(1f)) {
                        Text(p.name + " (" + p.stamp + "% / mahila " + p.stampW + "% / reg " + p.reg + "%)", maxLines = 2)
                    }
                    IconButton({ LandPresets.delete(p.name) }) { Icon(Icons.Default.Delete, "delete") }
                }
            }
        }

        if (areaSqft > 0) {
            val report = StringBuilder()
            report.append("ZAMEEN KA HISAAB\n\nTotal area: " + "%,.2f".format(Locale.US, areaSqft) + " sq ft\n" + areaLines() + "\nRate ikai: " + unitName(rateU) + "\n")
            report.append("Deal rate: " + inrIN(num(rate)) + " per " + unitName(rateU) + "\n")
            if (num(circle) > 0) report.append("Circle rate: " + inrIN(num(circle)) + " per " + unitName(rateU) + "\n")
            report.append("\nZameen ki maaliyat (deal rate se): " + inrIN(out.deal) + "\n")
            if (out.circle > 0) report.append("Zameen ki maaliyat (circle rate se): " + inrIN(out.circle) + "\n")
            report.append("Stamp duty ka aadhaar: " + inrIN(out.base) + "\n\n")
            report.append("Stamp duty (" + "%.2f".format(Locale.US, stampUse) + "%): " + inrIN(out.stamp) + "\n")
            if (out.sur > 0) report.append("Surcharge/cess: " + inrIN(out.sur) + "\n")
            report.append("Registration fee: " + inrIN(out.reg) + "\n")
            if (out.road > 0) report.append("Road side tax/charge: " + inrIN(out.road) + "\n")
            if (out.brok > 0) report.append("Dalali: " + inrIN(out.brok) + "\n")
            if (out.other > 0) report.append("Anya kharch: " + inrIN(out.other) + "\n")
            report.append("\nKul charges (maaliyat ke alawa): " + inrIN(out.charges) + "\nKUL LAGAT (maaliyat + charges): " + inrIN(out.total) + "\n")
            if (areaSqft > 0 && out.total > 0) report.append("Asli lagat per sq ft: " + inrIN(out.total / areaSqft) + "\n")
            report.append("\nNote: Rates aapke daale hue hain. Ye sirf andaaza hai, final raqam sub-registrar/authority se pakki kar lein.")

            ToolCard("Hisaab (kul lagat)") {
                Line("Zameen (deal rate)", inrIN(out.deal))
                if (out.circle > 0) Line("Zameen (circle rate)", inrIN(out.circle))
                Line("Stamp duty ka aadhaar", inrIN(out.base))
                Line("Stamp duty", inrIN(out.stamp))
                if (out.sur > 0) Line("Surcharge / cess", inrIN(out.sur))
                Line("Registration fee", inrIN(out.reg))
                if (out.road > 0) Line("Road side tax/charge", inrIN(out.road))
                if (out.brok > 0) Line("Dalali", inrIN(out.brok))
                if (out.other > 0) Line("Anya kharch", inrIN(out.other))
                HorizontalDivider()
                Line("Kul charges", inrIN(out.charges), true)
                Line("KUL LAGAT", inrIN(out.total), true)
                if (inrShort(out.total).isNotBlank()) Text("≈ " + inrShort(out.total), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }
            OutBox(report.toString(), "Zameen_Hisab")
        }
    }
}
