package com.dsingh.advocate

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.provider.DocumentsContract
import android.text.StaticLayout
import android.text.TextPaint
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.launch
import java.io.File
import java.time.temporal.ChronoUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object Export {
    private fun dir(ctx: Context) = File(ctx.cacheDir, "exports").apply { mkdirs() }
    private fun safe(n: String) = n.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40).ifBlank { "Draft" }
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    fun clean(t: String): String = t.lines().joinToString("\n") { l ->
        l.replace("**", "").replace("__", "")
            .replace(Regex("^\\s*#{1,6}\\s*"), "")
            .replace(Regex("^(\\s*)[*-]\\s+"), "\$1• ")
    }

    fun pdf(ctx: Context, name: String, text: String): File {
        val doc = PdfDocument()
        val w = 595; val h = 842; val mg = 48
        val body = clean(text)
        val paint = TextPaint().apply { textSize = 12f; isAntiAlias = true; color = android.graphics.Color.BLACK }
        val foot = Paint().apply { textSize = 9f; isAntiAlias = true; color = android.graphics.Color.GRAY }
        val layout = StaticLayout.Builder.obtain(body, 0, body.length, paint, w - 2 * mg).setLineSpacing(3f, 1f).build()
        val head = letterhead()
        val hp = TextPaint().apply { textSize = 11f; isAntiAlias = true; typeface = Typeface.DEFAULT_BOLD; color = android.graphics.Color.BLACK }
        val hl = if (head.isBlank()) null else StaticLayout.Builder.obtain(head, 0, head.length, hp, w - 2 * mg)
            .setAlignment(Layout.Alignment.ALIGN_CENTER).build()
        val hH = if (hl == null) 0 else hl.height + 18
        val ph = h - 2 * mg
        var start = 0
        var pg = 1
        while (start < layout.lineCount) {
            val avail = if (pg == 1) ph - hH else ph
            val yOff = if (pg == 1) hH else 0
            val top = layout.getLineTop(start)
            var end = start
            while (end < layout.lineCount && layout.getLineBottom(end) - top <= avail) end++
            if (end == start) end = start + 1
            val page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pg).create())
            val cv = page.canvas
            if (pg == 1 && hl != null) {
                cv.save(); cv.translate(mg.toFloat(), mg.toFloat()); hl.draw(cv); cv.restore()
                val ly = (mg + hl.height + 8).toFloat()
                cv.drawLine(mg.toFloat(), ly, (w - mg).toFloat(), ly, foot)
            }
            cv.save()
            cv.translate(mg.toFloat(), (mg + yOff - top).toFloat())
            cv.clipRect(0f, top.toFloat(), (w - 2 * mg).toFloat(), layout.getLineBottom(end - 1).toFloat())
            layout.draw(cv)
            cv.restore()
            cv.drawText("- " + pg + " -", (w / 2 - 10).toFloat(), (h - 22).toFloat(), foot)
            doc.finishPage(page)
            start = end; pg++
        }
        val f = File(dir(ctx), safe(name) + ".pdf")
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
        return f
    }

    fun docx(ctx: Context, name: String, text: String): File {
        val f = File(dir(ctx), safe(name) + ".docx")
        val hdr = letterhead().lines().filter { it.isNotBlank() }.joinToString("") {
            "<w:p><w:pPr><w:jc w:val=\"center\"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val=\"22\"/></w:rPr><w:t xml:space=\"preserve\">" + esc(it) + "</w:t></w:r></w:p>"
        }
        val paras = hdr + (if (hdr.isBlank()) "" else "<w:p/>") + clean(text).lines().joinToString("") {
            "<w:p><w:r><w:rPr><w:sz w:val=\"24\"/></w:rPr><w:t xml:space=\"preserve\">" + esc(it) + "</w:t></w:r></w:p>"
        }
        ZipOutputStream(f.outputStream()).use { z ->
            fun put(n: String, s: String) { z.putNextEntry(ZipEntry(n)); z.write(s.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            put("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>""")
            put("_rels/.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>""")
            put("word/document.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>""" + paras +
                """<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>""")
        }
        return f
    }

    fun backupFile(ctx: Context): File {
        val f = File(dir(ctx), "D-Singh-Advocate-backup.json")
        f.writeText(Repo.export())
        return f
    }
}

object Backup {
    fun setFolder(ctx: Context, tree: Uri) {
        try {
            ctx.contentResolver.takePersistableUriPermission(tree,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            val doc = DocumentsContract.createDocument(ctx.contentResolver, parent, "application/json", "D-Singh-Advocate-backup.json")
            Prefs.bkUri = doc?.toString() ?: ""
            write(ctx)
        } catch (e: Exception) { Prefs.bkUri = "" }
    }

    fun write(ctx: Context) {
        val u = Prefs.bkUri
        if (u.isBlank()) return
        val data = Repo.export()
        Thread {
            try { ctx.contentResolver.openOutputStream(Uri.parse(u), "wt")?.use { it.write(data.toByteArray()) } } catch (e: Exception) { }
        }.start()
    }
}

fun Context.shareFile(f: File, mime: String) {
    val u = FileProvider.getUriForFile(this, packageName + ".files", f)
    startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, u)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null))
}

@Composable
fun ToolCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(width = 4.dp, height = 18.dp).clip(RoundedCornerShape(2.dp)).background(MaterialTheme.colorScheme.primary))
                Spacer(Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.titleMedium)
            }
            content()
        }
    }
}

@Composable
fun ToolsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val presets = listOf(
        Triple("Money recovery / contract – 3 saal", 3L, 'y'), Triple("Specific performance – 3 saal", 3L, 'y'),
        Triple("Immovable property possession – 12 saal", 12L, 'y'), Triple("Appeal (decree), High Court – 90 din", 90L, 'd'),
        Triple("Appeal (decree), District Court – 30 din", 30L, 'd'))
    var ld by remember { mutableStateOf(today().toString()) }
    var pi by remember { mutableIntStateOf(0) }
    var menu by remember { mutableStateOf(false) }
    var lr by remember { mutableStateOf("") }
    var nd by remember { mutableStateOf(today().toString()) }
    var nn by remember { mutableStateOf(today().toString()) }
    var nr by remember { mutableStateOf("") }
    var pr by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var f1 by remember { mutableStateOf(today().toString()) }
    var f2 by remember { mutableStateOf(today().toString()) }
    var comp by remember { mutableStateOf(false) }
    var ir by remember { mutableStateOf("") }
    var sec by remember { mutableStateOf("") }
    var ar by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var tpl by remember { mutableStateOf(false) }
    var rm by remember { mutableStateOf(today().toString()) }
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            val tx = try { ctx.contentResolver.openInputStream(u)?.bufferedReader()?.readText() } catch (e: Exception) { null }
            ar = if (tx != null) SecTable.import(ctx, tx).toString() + " rows import hue." else "File padh nahi payi."
        }
    }
    if (ToolNav.land) LandCalc { ToolNav.land = false } else if (tpl) TemplatesManager { tpl = false } else Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Tools", style = MaterialTheme.typography.headlineMedium)
        ToolCard("🏞 Zameen Calculator") {
            Text("Lambai-chaudai ya chaaron bhuja se area, zameen ki maaliyat, stamp duty, registration, road side tax aur kul lagat.", style = MaterialTheme.typography.bodySmall)
            Button({ ToolNav.land = true }) { Text("Calculator kholo") }
        }
        ToolCard("Apni templates") {
            Text("Notice, vakalatnama ya koi bhi draft apne format me save karo. Case ki details apne aap bhar jayengi.", style = MaterialTheme.typography.bodySmall)
            Button({ tpl = true }) { Text("Templates kholo") }
        }
        ToolCard("Limitation calculator") {
            DateField("Cause of action / decree date", ld) { ld = it }
            Box {
                OutlinedButton({ menu = true }, Modifier.fillMaxWidth()) { Text(presets[pi].first) }
                DropdownMenu(menu, { menu = false }) {
                    presets.forEachIndexed { i, p -> DropdownMenuItem(text = { Text(p.first) }, onClick = { pi = i; menu = false }) }
                }
            }
            Button({ val p = presets[pi]; val e = addD(ld, p.second, p.third); lr = "Last date: " + fmtD(e) + " (" + rel(e) + ")" }) { Text("Calculate") }
            if (lr.isNotBlank()) Text(lr, fontWeight = FontWeight.Bold)
            Text("Andaaza hai. Section 12 (time exclusion) aur condonation alag verify karo.", style = MaterialTheme.typography.bodySmall)
        }
        ToolCard("Cheque bounce (S.138 NI Act)") {
            DateField("Bank memo (dishonour) date", nd) { nd = it }
            DateField("Notice bhejne ki date", nn) { nn = it }
            Button({
                val a = addD(nd, 30, 'd'); val r = addD(nn, 15, 'd'); val c = addD(r, 30, 'd')
                val late = (parseD(nn) ?: today()).isAfter(parseD(a) ?: today())
                nr = "Notice ki last date: " + fmtD(a) + (if (late) "  ⚠ late" else "") + "\nPayment ki 15 din ki window: " + fmtD(r) +
                    " tak\nComplaint ki last date: " + fmtD(c) + " (" + rel(c) + ")"
            }) { Text("Dates nikalo") }
            if (nr.isNotBlank()) Text(nr, fontWeight = FontWeight.Bold)
        }
        ToolCard("Interest calculator") {
            F("Principal ₹", pr, KeyboardType.Number) { pr = it }
            F("Rate % per saal", rate, KeyboardType.Decimal) { rate = it }
            DateField("Se", f1) { f1 = it }
            DateField("Tak", f2) { f2 = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!comp, { comp = false }, { Text("Simple") })
                FilterChip(comp, { comp = true }, { Text("Compound (yearly)") })
            }
            Button({
                val p = pr.toDoubleOrNull(); val r = rate.toDoubleOrNull(); val a = parseD(f1); val b = parseD(f2)
                if (p == null || r == null || a == null || b == null) ir = "Sab fields bharo."
                else {
                    val days = ChronoUnit.DAYS.between(a, b).toDouble()
                    val i = Calc.interest(p, r, days, comp)
                    ir = days.toLong().toString() + " din\nInterest: ₹" + "%,.2f".format(i) + "\nTotal: ₹" + "%,.2f".format(p + i)
                }
            }) { Text("Calculate") }
            if (ir.isNotBlank()) Text(ir, fontWeight = FontWeight.Bold)
        }
        ToolCard("IPC / CrPC / Evidence ↔ BNS / BNSS / BSA") {
            F("Section (jaise IPC 420, CrPC 438)", sec) { sec = it }
            Button({
                if (sec.isNotBlank()) {
                    val local = SecTable.find(sec)
                    if (local.isNotEmpty()) ar = "Aapki imported official table se:\n" + local.joinToString("\n")
                    else scope.launch {
                        busy = true
                        ar = Ai.ask("Section: " + sec + "\nIska naya/purana equivalent batao (IPC-BNS, CrPC-BNSS, Evidence Act-BSA): section number, short meaning, punishment ya procedure. Chhota jawab do aur verify karne ka note do.")
                        busy = false
                    }
                }
            }, enabled = !busy) { Text("Dhundo") }
            OutlinedButton({ imp.launch(arrayOf("*/*")) }) { Text("Official table CSV import") }
            Text("CSV: purana,naya,title (har line me ek). Table me " + SecTable.rows.size + " rows. Pehle ye table dekhi jati hai, phir AI.", style = MaterialTheme.typography.bodySmall)
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 6.dp))
            if (ar.isNotBlank()) OutBox(ar, "Section")
        }
        ToolCard("Reports") {
            DateField("Mahina (koi bhi date chuno)", rm) { rm = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ ctx.shareFile(Export.pdf(ctx, "Report_" + rm.take(7), Reports.monthReport(Repo.cases, rm.take(7))), "application/pdf") }) { Text("Monthly PDF") }
                OutlinedButton({
                    val f = File(ctx.cacheDir, "exports/D-Singh-Advocate-cases.csv")
                    f.parentFile?.mkdirs()
                    f.writeText("\uFEFF" + Reports.casesCsv(Repo.cases))
                    ctx.shareFile(f, "text/csv")
                }) { Text("Cases CSV") }
            }
        }
        ToolCard("eCourts") {
            Text("Case status ke liye official site kholo (auto-fetch ka koi official API nahi hai).", style = MaterialTheme.typography.bodySmall)
            OutlinedButton({ ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://services.ecourts.gov.in/ecourtindia_v6/"))) }) { Text("eCourts kholo") }
        }
    }
}
