package com.dsingh.advocate

import android.Manifest
import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import java.util.UUID
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Logx.init(this); Prefs.init(this); Repo.init(this); Templates.init(this); SecTable.init(this); Reminders.scheduleAll(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { App() }
    }
    override fun onStop() { super.onStop(); Lock.stopAt = System.currentTimeMillis() }
    override fun onStart() {
        super.onStart()
        if (Prefs.lock && !Lock.busy && System.currentTimeMillis() - Lock.stopAt > 30000L) Lock.unlocked = false
    }
}

fun Context.wa(phone: String, msg: String) {
    val n = phone.filter { it.isDigit() }.takeLast(10)
    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/91" + n + "?text=" + Uri.encode(msg))))
}
fun Context.sms(phone: String, msg: String) {
    startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phone)).putExtra("sms_body", msg))
}
fun Context.share(t: String) {
    startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), null))
}

object Lock {
    var unlocked by mutableStateOf(false)
    var busy = false
    var stopAt = 0L
}

@Composable
fun App() {
    val dark = isSystemInDarkTheme()
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Color(0xFFE0A94A)) else lightColorScheme(primary = Color(0xFF8A5A14))) {
        Surface(Modifier.fillMaxSize()) {
            val ctx = LocalContext.current
            val auth = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
                Lock.busy = false
                if (r.resultCode == Activity.RESULT_OK) { Lock.stopAt = System.currentTimeMillis(); Lock.unlocked = true }
            }
            val launchAuth: () -> Unit = {
                val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                val i = km.createConfirmDeviceCredentialIntent("D Singh Advocate", "Unlock karo")
                if (i == null) Lock.unlocked = true else { Lock.busy = true; auth.launch(i) }
            }
            if (Prefs.lock && !Lock.unlocked) {
                LaunchedEffect(Unit) { launchAuth() }
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Logo(96.dp)
                    Spacer(Modifier.height(12.dp))
                    Text("D Singh Advocate", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(12.dp))
                    Button(launchAuth) { Text("Unlock") }
                }
            } else Main()
        }
    }
}

@Composable
fun Main() {
    var tab by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<String?>(null) }
    BackHandler(open != null) { open = null }
    BackHandler(open == null && tab == 5) { tab = 0 }
    Scaffold(bottomBar = {
        if (open == null) NavigationBar {
            listOf("Home" to Icons.Default.Home, "Cases" to Icons.Default.List, "Calendar" to Icons.Default.DateRange,
                "AI" to Icons.Default.Send, "Tools" to Icons.Default.Build).forEachIndexed { i, (l, ic) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, l) }, label = { Text(l, maxLines = 1) })
            }
        }
    }) { p ->
        Box(Modifier.padding(p).fillMaxSize()) {
            val o = open
            if (o != null) CaseScreen(o) { open = null } else when (tab) {
                0 -> Home({ open = it }, { tab = 5 })
                1 -> Cases { open = it }
                2 -> CalendarScreen { open = it }
                3 -> AiScreen { open = it }
                4 -> ToolsScreen()
                else -> SettingsScreen()
            }
        }
    }
}

@Composable
fun F(l: String, v: String, kb: KeyboardType = KeyboardType.Text, set: (String) -> Unit) =
    OutlinedTextField(v, set, Modifier.fillMaxWidth().padding(vertical = 3.dp), label = { Text(l) },
        keyboardOptions = KeyboardOptions(keyboardType = kb))

@Composable
fun DateField(l: String, v: String, set: (String) -> Unit) {
    val ctx = LocalContext.current
    OutlinedButton({
        val d = parseD(v) ?: today()
        android.app.DatePickerDialog(ctx, { _, y, m, day -> set("%04d-%02d-%02d".format(y, m + 1, day)) },
            d.year, d.monthValue - 1, d.dayOfMonth).show()
    }, Modifier.fillMaxWidth().padding(vertical = 3.dp)) { Text(l + ": " + (if (v.isBlank()) "chuno" else fmtD(v) + dayNote(v))) }
}

@Composable
fun MicButton(onText: (String) -> Unit) {
    val ctx = LocalContext.current
    val l = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let(onText)
    }
    FilledTonalIconButton({
        try {
            l.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"))
        } catch (e: Exception) { Toast.makeText(ctx, "Voice input is phone me available nahi", Toast.LENGTH_SHORT).show() }
    }) { Text("🎤") }
}

@Composable
fun OutBox(t: String, name: String = "Draft", caseId: String? = null) {
    val ctx = LocalContext.current
    val cb = LocalClipboardManager.current
    Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Column(Modifier.padding(12.dp)) {
            SelectionContainer { Text(t, color = if (t.startsWith("ERR")) MaterialTheme.colorScheme.error else Color.Unspecified) }
            if (!t.startsWith("ERR")) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    OutlinedButton({ cb.setText(AnnotatedString(t)) }) { Text("Copy") }
                    OutlinedButton({ ctx.share(t) }) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(4.dp)); Text("Share") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({ ctx.shareFile(Export.pdf(ctx, name, t), "application/pdf") }) { Text("PDF") }
                    Button({ ctx.shareFile(Export.docx(ctx, name, t), "application/vnd.openxmlformats-officedocument.wordprocessingml.document") }) { Text("Word") }
                    if (caseId != null) OutlinedButton({
                        Docs.addFile(ctx, caseId, Export.pdf(ctx, name, t), name + ".pdf", "Draft", "application/pdf")
                        Toast.makeText(ctx, "Case Docs me save ho gaya", Toast.LENGTH_SHORT).show()
                    }) { Text("Case me save") }
                }
            }
        }
    }
}

@Composable
fun CaseCard(c: Case, onClick: () -> Unit) {
    val od = (dayDiff(c.next) ?: 0L) < 0L && c.active
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(onClick = onClick)) {
        Column(Modifier.padding(12.dp)) {
            Text(c.title, fontWeight = FontWeight.Bold)
            Text(listOf(c.no, c.court).filter { it.isNotBlank() }.joinToString(" · "), style = MaterialTheme.typography.bodySmall)
            Text(c.client + (if (c.stage.isNotBlank()) " · " + c.stage else ""), style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (c.next.isBlank()) "Tareekh nahi" else "📅 " + fmtD(c.next) + " · " + rel(c.next) + dayNote(c.next),
                    color = if (od || c.next.isBlank()) MaterialTheme.colorScheme.error else Color.Unspecified)
                if (c.pending > 0) Text("Baaki " + inr(c.pending))
                if (!c.active) Text("Disposed")
            }
        }
    }
}

fun LazyListScope.sec(t: String, l: List<Case>, open: (String) -> Unit) {
    if (l.isEmpty()) return
    item { Text(t, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 14.dp, bottom = 4.dp)) }
    items(l) { CaseCard(it) { open(it.id) } }
}

@Composable
fun Stat(l: String, v: String, m: Modifier) {
    Card(m) { Column(Modifier.padding(12.dp)) {
        Text(v, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        Text(l, style = MaterialTheme.typography.bodySmall)
    } }
}

@Composable
fun Home(open: (String) -> Unit, goSet: () -> Unit) {
    val all = Repo.cases
    val act = all.filter { it.active }
    val wk = act.filter { (dayDiff(it.next) ?: -1L) in 0L..7L }.sortedBy { it.next }
    val od = act.filter { (dayDiff(it.next) ?: 0L) < 0L }
    val nd = act.filter { it.next.isBlank() }
    val fees = act.filter { it.pending > 0 }.sortedByDescending { it.pending }.take(5)
    val tk = act.flatMap { cs -> cs.tasks.filter { !it.done && (dayDiff(it.due) ?: 99L) <= 2L }.map { cs to it } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Logo(36.dp)
                Spacer(Modifier.width(10.dp))
                Text("D Singh Advocate", modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                IconButton(goSet) { Icon(Icons.Default.Settings, "settings") }
            }
            if (Prefs.name.isNotBlank()) Text("Adv. " + Prefs.name)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Stat("Active cases", act.size.toString(), Modifier.weight(1f))
                Stat("Is hafte hearings", wk.size.toString(), Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Stat("Fees baaki", inr(all.sumOf { it.pending }), Modifier.weight(1f))
                Stat("Disposed", all.count { !it.active }.toString(), Modifier.weight(1f))
            }
            if (all.isEmpty()) Text("Cases tab me + dabake pehla case add karo. Settings me Gemini key daalo to AI features chalenge.",
                modifier = Modifier.padding(top = 14.dp))
        }
        sec("⚠ Tareekh nikal gayi, update karo", od, open)
        sec("Agle 7 din ki hearings", wk, open)
        sec("Bina tareekh ke cases", nd, open)
        sec("Sabse zyada fees baaki", fees, open)
        if (tk.isNotEmpty()) {
            item { Text("☑ Urgent tasks", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 14.dp, bottom = 4.dp)) }
            items(tk) { (cs, t) ->
                Card(Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { open(cs.id) }) {
                    Text(t.text + " · " + cs.title + " · " + rel(t.due), Modifier.padding(12.dp))
                }
            }
        }
    }
}

@Composable
fun Cases(open: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf(false) }
    var showAll by remember { mutableStateOf(false) }
    val l = Repo.cases.filter { (showAll || it.active) && listOf(it.title, it.no, it.court, it.client, it.opp).joinToString(" ").contains(q, true) }
        .sortedBy { it.next.ifBlank { "9" } }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(q, { q = it }, Modifier.weight(1f), label = { Text("Search: naam, case no., court") }, singleLine = true)
            Spacer(Modifier.width(8.dp))
            FilledIconButton({ dlg = true }) { Icon(Icons.Default.Add, "add") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(showAll, { showAll = it }); Text("Disposed bhi dikhao") }
        LazyColumn { items(l) { CaseCard(it) { open(it.id) } } }
    }
    if (dlg) CaseDialog(null) { dlg = false }
}

@Composable
fun CaseDialog(init: Case?, onClose: () -> Unit) {
    var c by remember { mutableStateOf(init ?: Case()) }
    var confl by remember { mutableStateOf<List<Case>>(emptyList()) }
    AlertDialog(onDismissRequest = onClose,
        title = { Text(if (init == null) "Naya case" else "Case edit") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (confl.isNotEmpty()) Text("⚠ Conflict check: " + confl.joinToString("; ") { it.title + " (" + it.client + " vs " + it.opp + ")" } +
                    "\nPhir bhi save karna ho to dobara Save dabao.", color = MaterialTheme.colorScheme.error)
                F("Case title (A vs B)", c.title) { c = c.copy(title = it) }
                F("Case no.", c.no) { c = c.copy(no = it) }
                F("CNR number (16 akshar)", c.cnr) { c = c.copy(cnr = it.uppercase()) }
                F("Court", c.court) { c = c.copy(court = it) }
                F("Judge", c.judge) { c = c.copy(judge = it) }
                F("Type (Civil/Criminal/Family)", c.type) { c = c.copy(type = it) }
                F("Client ka naam", c.client) { c = c.copy(client = it) }
                F("Client phone", c.phone, KeyboardType.Phone) { c = c.copy(phone = it) }
                F("Opposite party", c.opp) { c = c.copy(opp = it) }
                DateField("Next hearing", c.next) { c = c.copy(next = it) }
                F("Total fees ₹", if (c.fee > 0) c.fee.toString() else "", KeyboardType.Number) { c = c.copy(fee = it.toLongOrNull() ?: 0L) }
                F("Notes", c.notes) { c = c.copy(notes = it) }
            }
        },
        confirmButton = { TextButton({
            if (c.title.isNotBlank()) {
                val cf = if (init == null && confl.isEmpty()) Repo.cases.filter { o -> sameName(c.client, o.opp) || sameName(c.opp, o.client) } else emptyList()
                if (cf.isNotEmpty()) confl = cf else { Repo.upsert(c); onClose() }
            }
        }) { Text("Save") } },
        dismissButton = { TextButton(onClose) { Text("Cancel") } })
}

@Composable
fun CalendarScreen(open: (String) -> Unit) {
    val l = Repo.cases.filter { it.active && it.next.isNotBlank() }.sortedBy { it.next }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp)) {
        item { Text("📅 Hearing Calendar", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary) }
        if (l.isEmpty()) item { Text("Koi hearing scheduled nahi.", modifier = Modifier.padding(top = 12.dp)) }
        l.groupBy { it.next }.forEach { (d, cs) ->
            item {
                Text(fmtD(d) + " · " + rel(d), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp, bottom = 2.dp),
                    color = if ((dayDiff(d) ?: 0L) < 0L) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            }
            items(cs) { CaseCard(it) { open(it.id) } }
        }
        sec("Bina tareekh ke (pending)", Repo.cases.filter { it.active && it.next.isBlank() }, open)
    }
}

@Composable
fun CaseScreen(id: String, close: () -> Unit) {
    val c = Repo.cases.find { it.id == id }
    if (c == null) { LaunchedEffect(Unit) { close() }; return }
    var tab by remember { mutableIntStateOf(0) }
    var edit by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(close) { Icon(Icons.Default.ArrowBack, "back") }
            Column(Modifier.weight(1f)) {
                Text(c.title, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(c.no + " · " + c.court, style = MaterialTheme.typography.bodySmall, maxLines = 1)
            }
            IconButton({ edit = true }) { Icon(Icons.Default.Edit, "edit") }
        }
        ScrollableTabRow(tab, edgePadding = 0.dp) {
            listOf("Details", "Hearings", "Fees", "Tasks", "Docs", "Client", "AI").forEachIndexed { i, t -> Tab(tab == i, { tab = i }, text = { Text(t) }) }
        }
        Box(Modifier.weight(1f)) {
            when (tab) { 0 -> Details(c); 1 -> Hearings(c); 2 -> Fees(c); 3 -> TasksTab(c); 4 -> DocsTab(c); 5 -> Comms(c); else -> CaseAi(c) }
        }
    }
    if (edit) CaseDialog(c) { edit = false }
}

@Composable
fun Info(k: String, v: String) {
    Row { Text("$k: ", fontWeight = FontWeight.Bold); Text(v.ifBlank { "—" }) }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Details(c: Case) {
    val ctx = LocalContext.current
    val cb = LocalClipboardManager.current
    var del by remember { mutableStateOf(false) }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Info("Client", c.client); Info("Phone", c.phone); Info("Opposite party", c.opp)
        Info("Judge", c.judge); Info("Type", c.type); Info("Status", c.status); Info("CNR", c.cnr)
        Info("Next hearing", if (c.next.isBlank()) "—" else fmtD(c.next) + " (" + rel(c.next) + ")")
        Info("Fees", inr(c.fee) + " · mile " + inr(c.paid) + " · baaki " + inr(c.pending))
        Info("Notes", c.notes)
        if (c.phone.isNotBlank()) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button({ ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + c.phone))) }) { Icon(Icons.Default.Call, null) }
            Button({ ctx.wa(c.phone, reminderMsg(c)) }) { Text("WhatsApp reminder") }
            OutlinedButton({ ctx.sms(c.phone, reminderMsg(c)) }) { Text("SMS") }
        }
        if (c.phone.isNotBlank()) OutlinedButton({ ctx.wa(c.phone, statusMsg(c)) }) { Text("Status update bhejo (WhatsApp)") }
        Text("Stage", fontWeight = FontWeight.Bold)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            STAGES.forEach { s ->
                FilterChip(c.stage == s, { if (c.stage != s) Repo.upsert(c.copy(stage = s, stageLog = c.stageLog + Comm(today().toString(), s))) }, { Text(s) })
            }
        }
        c.stageLog.takeLast(5).reversed().forEach { Text(fmtD(it.date) + " → " + it.text, style = MaterialTheme.typography.bodySmall) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(c.noAi, { Repo.upsert(c.copy(noAi = it)) })
            Spacer(Modifier.width(8.dp))
            Text("Is case me AI band rakho (privacy)", modifier = Modifier.weight(1f))
        }
        OutlinedButton({
            cb.setText(AnnotatedString(c.cnr))
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://services.ecourts.gov.in/ecourtindia_v6/")))
        }) { Text("eCourts kholo" + if (c.cnr.isBlank()) "" else " (CNR copy hoga)") }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton({ Repo.upsert(c.copy(status = if (c.active) "Disposed" else "Active")) }) { Text(if (c.active) "Disposed mark" else "Reopen") }
            OutlinedButton({ del = true }) { Icon(Icons.Default.Delete, null); Text("Delete") }
        }
    }
    if (del) AlertDialog(onDismissRequest = { del = false }, title = { Text("Pakka delete?") },
        text = { Text("Ye case aur uska poora record hat jayega.") },
        confirmButton = { TextButton({ Repo.delete(c.id) }) { Text("Delete") } },
        dismissButton = { TextButton({ del = false }) { Text("Cancel") } })
}

@Composable
fun Hearings(c: Case) {
    var dlg by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Button({ dlg = true }) { Text("+ Hearing note") }
        LazyColumn { items(c.hearings.reversed()) { h ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Column(Modifier.padding(12.dp)) {
                Text(fmtD(h.date), fontWeight = FontWeight.Bold)
                Text(h.note.ifBlank { "—" })
                if (h.next.isNotBlank()) Text("Agli: " + fmtD(h.next), style = MaterialTheme.typography.bodySmall)
            } }
        } }
    }
    if (dlg) {
        var d by remember { mutableStateOf(today().toString()) }
        var n by remember { mutableStateOf("") }
        var x by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { dlg = false }, title = { Text("Hearing note") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) {
                DateField("Hearing date", d) { d = it }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(n, { n = it }, Modifier.weight(1f), label = { Text("Kya hua?") }, minLines = 3)
                    MicButton { n = (n + " " + it).trim() }
                }
                DateField("Agli tareekh", x) { x = it }
            } },
            confirmButton = { TextButton({
                Repo.upsert(c.copy(hearings = c.hearings + Hearing(d, n, x), next = if (x.isNotBlank()) x else c.next)); dlg = false
            }) { Text("Save") } },
            dismissButton = { TextButton({ dlg = false }) { Text("Cancel") } })
    }
}

fun receiptText(c: Case, p: Payment, n: Int): String {
    val no = if (c.no.isBlank()) "" else " (" + c.no + ")"
    return "FEE RECEIPT\n\nReceipt No: " + c.id.take(4).uppercase() + "-" + n + "\nDate: " + fmtD(p.date) +
        "\n\nReceived with thanks from " + c.client + " a sum of " + inr(p.amount) + " (" + p.mode +
        ") towards professional fees in the matter of \"" + c.title + "\"" + no + ", " + c.court + "." +
        "\n\nTotal fees: " + inr(c.fee) + "\nReceived so far: " + inr(c.paid) + "\nBalance: " + inr(c.pending) +
        "\n\n\n\n" + signoff() + "\n(Signature)"
}

@Composable
fun Fees(c: Case) {
    val ctx = LocalContext.current
    var dlg by remember { mutableStateOf(false) }
    var edlg by remember { mutableStateOf(false) }
    val spent = c.exps.sumOf { it.amount }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp)) {
        item {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                Text("Total: " + inr(c.fee)); Text("Mili: " + inr(c.paid))
                Text("Baaki: " + inr(c.pending), fontWeight = FontWeight.Bold)
                Text("Kharcha: " + inr(spent) + " · Net bacha: " + inr(c.paid - spent))
            } }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                Button({ dlg = true }) { Text("+ Payment") }
                Button({ edlg = true }) { Text("+ Kharcha") }
                OutlinedButton({ ctx.shareFile(Export.pdf(ctx, "Invoice_" + c.client, invoiceText(c)), "application/pdf") }) { Text("Invoice") }
            }
            if (c.pending > 0 && c.phone.isNotBlank()) OutlinedButton({ ctx.wa(c.phone, feeMsg(c)) }) { Text("Fees reminder (WhatsApp)") }
            Text("Payments", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        }
        items(c.pays.withIndex().reversed()) { (i, p) ->
            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) { Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(fmtD(p.date), Modifier.weight(1f)); Text(inr(p.amount) + " · " + p.mode)
                TextButton({ ctx.shareFile(Export.pdf(ctx, "Receipt_" + c.client, receiptText(c, p, i + 1)), "application/pdf") }) { Text("Receipt") }
            } }
        }
        if (c.exps.isNotEmpty()) item { Text("Kharcha", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
        items(c.exps.reversed()) { e ->
            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) { Row(Modifier.padding(12.dp)) {
                Text(fmtD(e.date), Modifier.weight(1f)); Text(inr(e.amount) + " · " + e.mode)
            } }
        }
    }
    if (dlg || edlg) {
        val isPay = dlg
        var a by remember { mutableStateOf("") }
        var m by remember { mutableStateOf(if (isPay) "Cash/UPI" else "") }
        var d by remember { mutableStateOf(today().toString()) }
        val close = { dlg = false; edlg = false }
        AlertDialog(onDismissRequest = close, title = { Text(if (isPay) "Payment mili" else "Kharcha") },
            text = { Column {
                F("Amount ₹", a, KeyboardType.Number) { a = it }
                F(if (isPay) "Mode" else "Kis cheez ka (court fee, travel...)", m) { m = it }
                DateField("Date", d) { d = it }
            } },
            confirmButton = { TextButton({
                val x = a.toLongOrNull() ?: 0L
                if (x > 0) {
                    Repo.upsert(if (isPay) c.copy(pays = c.pays + Payment(d, x, m)) else c.copy(exps = c.exps + Payment(d, x, m)))
                    close()
                }
            }) { Text("Save") } },
            dismissButton = { TextButton(close) { Text("Cancel") } })
    }
}

@Composable
fun TasksTab(c: Case) {
    val ctx = LocalContext.current
    var t by remember { mutableStateOf("") }
    var d by remember { mutableStateOf(today().toString()) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(t, { t = it }, Modifier.weight(1f), label = { Text("Naya task") })
            MicButton { t = (t + " " + it).trim() }
        }
        DateField("Due date", d) { d = it }
        Button({
            if (t.isNotBlank()) { Repo.upsert(c.copy(tasks = c.tasks + Todo(UUID.randomUUID().toString().take(8), t, d, false))); t = "" }
        }) { Text("+ Task add") }
        LazyColumn { items(c.tasks.sortedBy { it.done }) { x ->
            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) { Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(x.done, { v -> Repo.upsert(c.copy(tasks = c.tasks.map { if (it.id == x.id) it.copy(done = v) else it })) })
                Column(Modifier.weight(1f)) {
                    Text(x.text, textDecoration = if (x.done) TextDecoration.LineThrough else null)
                    Text(fmtD(x.due) + " · " + rel(x.due), style = MaterialTheme.typography.bodySmall)
                }
                IconButton({ Reminders.cancelTask(ctx, c, x); Repo.upsert(c.copy(tasks = c.tasks.filter { it.id != x.id })) }) { Icon(Icons.Default.Delete, "del") }
            } }
        } }
    }
}

@Composable
fun Comms(c: Case) {
    val ctx = LocalContext.current
    var t by remember { mutableStateOf("") }
    var cdlg by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Client ke saath communication history", fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(t, { t = it }, Modifier.weight(1f), label = { Text("Call / meeting / message note") })
            MicButton { t = (t + " " + it).trim() }
            IconButton({ if (t.isNotBlank()) { Repo.upsert(c.copy(comms = c.comms + Comm(today().toString(), t))); t = "" } }) { Icon(Icons.Default.Add, "add") }
        }
        LazyColumn {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 10.dp)) {
                    Text("Witness / Contacts", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton({ cdlg = true }) { Text("+ Add") }
                }
            }
            items(c.contacts) { k ->
                Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(k.name, fontWeight = FontWeight.Bold)
                            Text(k.role + " · " + k.phone, style = MaterialTheme.typography.bodySmall)
                        }
                        if (k.phone.isNotBlank()) IconButton({ ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + k.phone))) }) { Icon(Icons.Default.Call, "call") }
                        IconButton({ Repo.upsert(c.copy(contacts = c.contacts.filter { it != k })) }) { Icon(Icons.Default.Delete, "del") }
                    }
                }
            }
            item { Text("History", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
            items(c.comms.reversed()) { m ->
                Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) { Column(Modifier.padding(12.dp)) {
                    Text(fmtD(m.date), style = MaterialTheme.typography.bodySmall); Text(m.text)
                } }
            }
        }
    }
    if (cdlg) {
        var n by remember { mutableStateOf("") }
        var r by remember { mutableStateOf("Witness") }
        var p by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { cdlg = false }, title = { Text("Contact add karo") },
            text = { Column {
                F("Naam", n) { n = it }
                F("Role (Witness/Opposite counsel/Clerk...)", r) { r = it }
                F("Phone", p, KeyboardType.Phone) { p = it }
            } },
            confirmButton = { TextButton({
                if (n.isNotBlank()) { Repo.upsert(c.copy(contacts = c.contacts + Contact(n, r, p))); cdlg = false }
            }) { Text("Save") } },
            dismissButton = { TextButton({ cdlg = false }) { Text("Cancel") } })
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CaseAi(c: Case) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var out by remember { mutableStateOf(c.analysis) }
    var extra by remember { mutableStateOf("") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) scope.launch {
            busy = true
            val b = withContext(Dispatchers.IO) { try { ctx.contentResolver.openInputStream(u)?.readBytes() } catch (e: Exception) { null } }
            out = if (b == null) "ERR: File padh nahi paya" else if (b.size > 15_000_000) "ERR: PDF 15MB se badi hai" else Ai.ask(Ai.ANALYZE, pdf = b)
            if (!out.startsWith("ERR")) Repo.cases.find { it.id == c.id }?.let { Repo.upsert(it.copy(analysis = out)) }
            busy = false
        }
    }
    if (c.noAi) {
        Text("Is case me AI band hai (privacy). Details tab ke switch se chalu kar sakte ho.", modifier = Modifier.padding(16.dp))
        return
    }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("AI Case File Analyzer", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("PDF upload karo: summary, facts, legal provisions, opposite arguments, counter-arguments aur draft arguments milenge.", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
            Button({ pick.launch(arrayOf("application/pdf")) }, enabled = !busy) { Text("PDF analyze karo") }
            if (c.analysis.isNotBlank()) OutlinedButton({ out = c.analysis }) { Text("Saved analysis") }
        }
        Button({
            scope.launch { busy = true; out = Ai.ask(prepPrompt(c)); busy = false }
        }, enabled = !busy) { Text("📝 Hearing prep brief") }
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Text("Document Generator", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(extra, { extra = it }, Modifier.weight(1f), label = { Text("Details Hindi/Hinglish me likho ya bolo") }, minLines = 2)
            MicButton { extra = (extra + " " + it).trim() }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Legal Notice", "Affidavit", "Bail Application", "Plaint", "Written Statement", "Vakalatnama", "Reply to Notice", "Application").forEach { d ->
                OutlinedButton({
                    scope.launch {
                        busy = true
                        out = Ai.ask("Draft taiyar karo: " + d + "\n\nCASE DETAILS:\n" + ctxOf(c) + "\n\nADVOCATE KE INSTRUCTIONS:\n" + extra)
                        busy = false
                    }
                }, enabled = !busy) { Text(d) }
            }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 8.dp))
        if (out.isNotBlank()) OutBox(out, c.title, c.id)
    }
}

@Composable
fun AiScreen(open: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var mode by remember { mutableIntStateOf(0) }
    var inp by remember { mutableStateOf("") }
    var out by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var opened by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("🤖 AI Legal Assistant", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
            FilterChip(mode == 0, { mode = 0; out = "" }, { Text("Sawal / Draft") })
            FilterChip(mode == 1, { mode = 1; out = "" }, { Text("🎤 Hearing update") })
        }
        Text(if (mode == 0) "Hindi me case details likho: legal notice, bail application, plaint, affidavit, section ya judgment samajhna, sab pooch sakte ho."
        else "Bolo: \"Ram Kumar ke case ki agli hearing 15 December ko hai\". Case aur tareekh apne aap update hogi.", style = MaterialTheme.typography.bodySmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(inp, { inp = it }, Modifier.weight(1f).padding(vertical = 6.dp), minLines = 3)
            MicButton { inp = (inp + " " + it).trim() }
        }
        Button({
            if (inp.isBlank()) return@Button
            scope.launch {
                busy = true; opened = null
                if (mode == 0) out = Ai.ask(inp) else {
                    val list = Repo.cases.filter { it.active }.joinToString("\n") { it.id + "|" + it.title + "|" + it.client }
                    val r = Ai.ask("Aaj ki date " + today() + ".\nCases (id|title|client):\n" + list + "\n\nAdvocate ne kaha: \"" + inp +
                        "\"\nSahi case dhundo aur sirf JSON do: {\"id\":\"case id ya khali\",\"next\":\"YYYY-MM-DD ya khali\",\"note\":\"hearing me kya hua ya khali\"}. Agar saal nahi bola to aane wali agli date lo.",
                        system = "", json = true)
                    out = if (r.startsWith("ERR")) r else try {
                        val j = JSONObject(r.trim())
                        val cs = Repo.cases.find { it.id == j.optString("id") }
                        if (cs == null) "Case match nahi hua. Client ya case ka naam saaf bolo." else {
                            val nx = j.optString("next").let { if (parseD(it) != null) it else "" }
                            val nt = j.optString("note")
                            Repo.upsert(cs.copy(next = if (nx.isNotBlank()) nx else cs.next,
                                hearings = if (nx.isNotBlank() || nt.isNotBlank()) cs.hearings + Hearing(today().toString(), nt, nx) else cs.hearings))
                            opened = cs.id
                            "✅ " + cs.title + (if (nx.isNotBlank()) "\nAgli hearing: " + fmtD(nx) + " (reminder set)" else "") + (if (nt.isNotBlank()) "\nNote: " + nt else "")
                        }
                    } catch (e: Exception) { "ERR: AI ka jawab samajh nahi aaya, dobara try karo." }
                }
                busy = false
            }
        }, enabled = !busy) { Text(if (mode == 0) "Bhejo" else "Update karo") }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 8.dp))
        if (out.isNotBlank()) OutBox(out)
        opened?.let { id -> OutlinedButton({ open(id) }) { Text("Case kholo") } }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(Prefs.name) }
    var key by remember { mutableStateOf(Prefs.key) }
    var model by remember { mutableStateOf(Prefs.model) }
    var lock by remember { mutableStateOf(Prefs.lock) }
    var enrol by remember { mutableStateOf(Prefs.enrol) }
    var addr by remember { mutableStateOf(Prefs.addr) }
    var phone by remember { mutableStateOf(Prefs.phone) }
    var email by remember { mutableStateOf(Prefs.email) }
    var holidays by remember { mutableStateOf(Prefs.holidays) }
    var anon by remember { mutableStateOf(Prefs.anon) }
    var ground by remember { mutableStateOf(Prefs.ground) }
    var bkPass by remember { mutableStateOf("") }
    var logDlg by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf("") }
    val folder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) { Backup.setFolder(ctx, u); msg = if (Prefs.bkUri.isNotBlank()) "Auto backup chalu: har save par file update hogi." else "Is folder me backup nahi ban paya, doosra folder chuno." }
    }
    val rf = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            val t = try { ctx.contentResolver.openInputStream(u)?.bufferedReader()?.readText() } catch (e: Exception) { null }
            msg = if (t != null && Repo.import(t)) "Restore ho gaya." else "File galat hai."
        }
    }
    val zf = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) scope.launch {
            msg = "Restore ho raha hai..."
            val ok = withContext(Dispatchers.IO) { ZipBackup.restore(ctx, u, bkPass) }
            msg = if (ok) "ZIP restore ho gaya (cases + files)." else "ZIP galat hai ya password galat hai."
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("⚙ Settings", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
        F("Advocate ka naam", name) { name = it; Prefs.name = it }
        F("Enrolment no.", enrol) { enrol = it; Prefs.enrol = it }
        F("Office address", addr) { addr = it; Prefs.addr = it }
        F("Phone", phone, KeyboardType.Phone) { phone = it; Prefs.phone = it }
        F("Email", email, KeyboardType.Email) { email = it; Prefs.email = it }
        Text("Ye details har PDF/Word ke upar letterhead me aur AI drafts ke signature block me aayengi.", style = MaterialTheme.typography.bodySmall)
        F("Court holidays/vacation (YYYY-MM-DD, comma se)", holidays) { holidays = it; Prefs.holidays = it }
        Text("In dates par hearing rakhne par warning dikhegi. Sunday ki warning apne aap aati hai.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(key, { key = it; Prefs.key = it }, Modifier.fillMaxWidth().padding(vertical = 3.dp),
            label = { Text("Gemini API key") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
        F("Gemini model", model) { model = it; Prefs.model = it.trim() }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(anon, { anon = it; Prefs.anon = it })
            Spacer(Modifier.width(8.dp))
            Text("AI ko bhejne se pehle client/opposite party ka naam chhupao", modifier = Modifier.weight(1f))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(ground, { ground = it; Prefs.ground = it })
            Spacer(Modifier.width(8.dp))
            Text("Google Search grounding (current law, sources ke saath)", modifier = Modifier.weight(1f))
        }
        Text("PDF/photo ke andar ke naam mask nahi hote. Free Gemini tier ka data Google apne products sudharne me use kar sakta hai; confidential matters ke liye paid tier ya per-case AI band rakho (Google ke current terms dekh lena).", style = MaterialTheme.typography.bodySmall)
        Text("Free key: aistudio.google.com/apikey. Key sirf is phone me save hoti hai. Model ka naam error de to Google ke naye model naam se badal lo.", style = MaterialTheme.typography.bodySmall)
        HorizontalDivider(Modifier.padding(vertical = 12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(lock, { v ->
                val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                if (v && !km.isDeviceSecure) msg = "Pehle phone me screen lock (PIN/pattern/fingerprint) lagao."
                else { lock = v; Prefs.lock = v; Lock.unlocked = true; Lock.stopAt = System.currentTimeMillis() }
            })
            Spacer(Modifier.width(8.dp)); Text("App lock (phone PIN / fingerprint)")
        }
        HorizontalDivider(Modifier.padding(vertical = 12.dp))
        Text("Reminder health", fontWeight = FontWeight.Bold)
        val alarmMgr = ctx.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
        val exactOk = Build.VERSION.SDK_INT < 31 || alarmMgr.canScheduleExactAlarms()
        val batOk = (ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
        val notifOk = androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled()
        Text("Exact alarm: " + (if (exactOk) "OK ✅" else "band ❌") + " · Battery: " + (if (batOk) "unrestricted ✅" else "restricted ⚠") +
            " · Notification: " + (if (notifOk) "OK ✅" else "band ❌"), style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({
                if (Build.VERSION.SDK_INT >= 31) ctx.startActivity(Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)))
            }) { Text("Exact alarm") }
            OutlinedButton({ ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("Battery settings") }
        }
        Text("Xiaomi/Redmi: Settings > Apps > D Singh Advocate > Autostart ON, Battery saver > No restrictions.", style = MaterialTheme.typography.bodySmall)
        HorizontalDivider(Modifier.padding(vertical = 12.dp))
        Text("Backup / Restore", fontWeight = FontWeight.Bold)
        Text(if (Prefs.bkUri.isBlank()) "Auto backup: band" else "Auto backup: chalu", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ folder.launch(null) }) { Text("Backup folder chuno") }
            OutlinedButton({ ctx.shareFile(Export.backupFile(ctx), "application/json") }) { Text("Backup share") }
        }
        OutlinedButton({ rf.launch(arrayOf("*/*")) }, Modifier.padding(top = 6.dp)) { Text("File se restore karo (sirf data)") }
        Text("Files ke saath poora backup:", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        OutlinedTextField(bkPass, { bkPass = it }, Modifier.fillMaxWidth().padding(vertical = 3.dp),
            label = { Text("Backup password (khali = bina encryption)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
        Text("Password bhool gaye to encrypted backup koi nahi khol sakta, mai bhi nahi. Restore ke waqt wahi password upar bharo.", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({
                scope.launch {
                    msg = "Backup ban raha hai..."
                    val z = withContext(Dispatchers.IO) {
                        val zz = ZipBackup.create(ctx)
                        if (bkPass.isNotBlank()) {
                            val e = java.io.File(zz.parentFile, "D-Singh-Advocate-backup.dsa")
                            Crypt.encrypt(zz, e, bkPass); zz.delete(); e
                        } else zz
                    }
                    msg = ""
                    ctx.shareFile(z, if (bkPass.isNotBlank()) "application/octet-stream" else "application/zip")
                }
            }) { Text("ZIP backup") }
            OutlinedButton({ zf.launch(arrayOf("*/*")) }) { Text("ZIP restore") }
        }
        Text("Backup file plain text hai aur isme client ka data hota hai. Sirf apne private folder ya Drive me rakho. Folder ke liye khud ka naya folder banao (jaise D Singh Backup).", style = MaterialTheme.typography.bodySmall)
        OutlinedButton({ logDlg = true }, Modifier.padding(top = 10.dp)) { Text("Error log (mujhe bhejne ke liye)") }
        if (msg.isNotBlank()) Text(msg, modifier = Modifier.padding(top = 6.dp))
    }
    if (logDlg) AlertDialog(onDismissRequest = { logDlg = false }, title = { Text("Error log") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) {
            SelectionContainer { Text(Logx.read().ifBlank { "Koi error nahi." }, style = MaterialTheme.typography.bodySmall) }
        } },
        confirmButton = { TextButton({ ctx.share(Logx.read()) }) { Text("Share") } },
        dismissButton = { Row {
            TextButton({ Logx.clear(); logDlg = false }) { Text("Clear") }
            TextButton({ logDlg = false }) { Text("Band") }
        } })
}
