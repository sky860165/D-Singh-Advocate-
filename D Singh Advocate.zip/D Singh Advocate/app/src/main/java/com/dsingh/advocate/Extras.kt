package com.dsingh.advocate

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

fun letterhead(): String {
    val l = mutableListOf<String>()
    if (Prefs.name.isNotBlank()) l.add("ADV. " + Prefs.name.uppercase())
    if (Prefs.enrol.isNotBlank()) l.add("Enrolment No: " + Prefs.enrol)
    if (Prefs.addr.isNotBlank()) l.add(Prefs.addr)
    val c = listOf(Prefs.phone, Prefs.email).filter { it.isNotBlank() }.joinToString(" | ")
    if (c.isNotBlank()) l.add(c)
    return l.joinToString("\n")
}

fun statusMsg(c: Case): String {
    val h = c.hearings.lastOrNull()
    return "Namaste " + c.client + " ji, aapke case \"" + c.title + "\" ki update:\n" +
        (if (h != null) "Pichli hearing (" + fmtD(h.date) + "): " + h.note.ifBlank { "karyavahi hui" } + "\n" else "") +
        (if (c.next.isNotBlank()) "Agli tareekh: " + fmtD(c.next) + "\n" else "") +
        "– " + signoff()
}

fun prepPrompt(c: Case): String =
    "Aane wali hearing ke liye 1 page ka PREP BRIEF banao, Hinglish me, in sections ke saath: 1) Case ek line me 2) Ab tak kya hua (hearing history se timeline) " +
    "3) Is hearing ka objective 4) Bolne ke main points 5) Saath le jaane wale documents (neeche ki list se) 6) Possible sawal/objections aur unke jawab 7) Pending tasks. " +
    "Sirf diye gaye data ke basis par likho; jahan data nahi hai wahan [?] likho aur guess mat karo.\n\nCASE:\n" + ctxOf(c) +
    "\nNext hearing: " + fmtD(c.next) + "\nDocuments: " + c.docs.joinToString(", ") { it.cat + ": " + it.name } +
    "\nPending tasks: " + c.tasks.filter { !it.done }.joinToString("; ") { it.text + " (" + fmtD(it.due) + ")" } +
    "\nPichla AI analysis:\n" + c.analysis.take(3000)

data class Template(val id: String, val name: String, val body: String)

object Templates {
    var list by mutableStateOf(listOf<Template>())
    private lateinit var ctx: Context
    private fun f() = File(ctx.filesDir, "templates.json")
    fun init(c: Context) { ctx = c.applicationContext; try { load(f().readText()) } catch (e: Exception) { } }
    private fun load(s: String) {
        val a = JSONArray(s)
        list = (0 until a.length()).map { val o = a.getJSONObject(it); Template(o.optString("i"), o.optString("n"), o.optString("b")) }
    }
    fun export(): String = JSONArray(list.map { JSONObject().put("i", it.id).put("n", it.name).put("b", it.body) }).toString()
    private fun save() { try { f().writeText(export()) } catch (e: Exception) { } }
    fun import(s: String) { try { load(s); save() } catch (e: Exception) { } }
    fun upsert(t: Template) {
        list = if (list.any { it.id == t.id }) list.map { if (it.id == t.id) t else it } else list + t
        save()
    }
    fun delete(id: String) { list = list.filter { it.id != id }; save() }

    fun fill(body: String, c: Case?): String {
        val m = mutableMapOf("today" to fmtD(today().toString()), "advocate" to Prefs.name, "enrolment" to Prefs.enrol,
            "address" to Prefs.addr, "phone" to Prefs.phone)
        if (c != null) {
            m["client"] = c.client; m["case_title"] = c.title; m["case_no"] = c.no; m["court"] = c.court; m["judge"] = c.judge
            m["opp"] = c.opp; m["next_date"] = fmtD(c.next); m["fee"] = inr(c.fee); m["pending"] = inr(c.pending)
        }
        var r = body
        m.forEach { (k, v) -> r = r.replace("{" + k + "}", v.ifBlank { "________" }) }
        return r
    }

    private const val NOTICE = """LEGAL NOTICE

Date: {today}

To,
{opp}

Subject: Legal notice on behalf of my client {client}

Sir/Madam,

Under instructions from and on behalf of my client {client}, I hereby serve upon you the following notice:

1. [Facts of the matter]

2. [Default / cause of action]

3. [Demand]

You are called upon to comply with the above within [15] days of receipt of this notice, failing which my client shall be constrained to initiate appropriate legal proceedings, civil and/or criminal, at your risk as to costs and consequences.

{advocate}
Advocate
Enrolment No: {enrolment}
{address}"""

    private const val VAKALAT = """IN THE COURT OF {court}

Case No: {case_no}
{case_title}

VAKALATNAMA

I/We, {client}, the above-named party, do hereby appoint and retain Adv. {advocate} (Enrolment No. {enrolment}) to appear, act and plead for me/us in the above matter and to do all acts necessary for the conduct of the case, including filing and withdrawing documents, receiving and depositing money, and engaging other counsel.

I/We agree to ratify all acts done by the said Advocate in pursuance of this authority.

Date: {today}
Place: ____________

Signature of Client: ____________

Accepted: ____________ (Advocate)"""

    fun seed() {
        val add = listOf(Template("s_notice", "Legal Notice (basic)", NOTICE), Template("s_vakalat", "Vakalatnama", VAKALAT))
        list = list.filter { x -> add.none { it.id == x.id } } + add
        save()
    }
}

@Composable
fun TemplatesManager(onBack: () -> Unit) {
    var edit by remember { mutableStateOf<Template?>(null) }
    var isNew by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Default.ArrowBack, "back") }
            Text("📄 Templates", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
        }
        Text("Placeholders: {client} {case_title} {case_no} {court} {judge} {opp} {next_date} {fee} {pending} {today} {advocate} {enrolment} {address} {phone}",
            style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
            Button({ edit = Template(UUID.randomUUID().toString().take(8), "", ""); isNew = true }) { Text("+ Nayi template") }
            OutlinedButton({ Templates.seed() }) { Text("Starter formats") }
        }
        Text("Starter formats sirf generic dhaancha hain. Court aur case ke hisaab se khud check aur edit karo.", style = MaterialTheme.typography.bodySmall)
        LazyColumn {
            items(Templates.list) { t ->
                Card(Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { edit = t; isNew = false }) {
                    Column(Modifier.padding(12.dp)) {
                        Text(t.name, fontWeight = FontWeight.Bold)
                        Text(t.body.take(90), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                    }
                }
            }
        }
    }
    val e = edit
    if (e != null) {
        var n by remember(e.id) { mutableStateOf(e.name) }
        var b by remember(e.id) { mutableStateOf(e.body) }
        AlertDialog(onDismissRequest = { edit = null }, title = { Text(if (isNew) "Nayi template" else "Template edit") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) {
                F("Naam", n) { n = it }
                OutlinedTextField(b, { b = it }, Modifier.fillMaxWidth(), label = { Text("Text (placeholders ke saath)") }, minLines = 10)
            } },
            confirmButton = { TextButton({ if (n.isNotBlank()) { Templates.upsert(Template(e.id, n, b)); edit = null } }) { Text("Save") } },
            dismissButton = { Row {
                if (!isNew) TextButton({ Templates.delete(e.id); edit = null }) { Text("Delete") }
                TextButton({ edit = null }) { Text("Cancel") }
            } })
    }
}

val STAGES = listOf("Filing", "Notice/Summons", "Pleadings", "Evidence", "Arguments", "Judgment", "Appeal/Execution")

fun sameName(a: String, b: String): Boolean = a.isNotBlank() && b.isNotBlank() && a.trim().equals(b.trim(), true)

fun invoiceText(c: Case): String {
    val sb = StringBuilder()
    sb.append("FEE INVOICE\n\nInvoice No: INV-" + c.id.take(4).uppercase() + "-" + today().toString().replace("-", "") +
        "\nDate: " + fmtD(today().toString()) + "\n\nTo: " + c.client + "\nMatter: " + c.title +
        (if (c.no.isBlank()) "" else " (" + c.no + ")") + "\nCourt: " + c.court + "\n\n")
    sb.append("Professional fees: " + inr(c.fee) + "\n")
    if (c.pays.isNotEmpty()) {
        sb.append("\nPayments received:\n")
        c.pays.forEach { sb.append("  " + fmtD(it.date) + "  " + inr(it.amount) + "  (" + it.mode + ")\n") }
    }
    sb.append("\nTotal received: " + inr(c.paid) + "\nBALANCE DUE: " + inr(c.pending) + "\n\n\n" + signoff() + "\n(Signature)")
    return sb.toString()
}

object SecTable {
    var rows by mutableStateOf(listOf<String>())
    fun init(c: Context) { try { rows = File(c.filesDir, "sections.csv").readLines().filter { it.isNotBlank() } } catch (e: Exception) { } }
    fun import(c: Context, text: String): Int {
        val l = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        rows = l
        try { File(c.filesDir, "sections.csv").writeText(l.joinToString("\n")) } catch (e: Exception) { }
        return l.size
    }
    fun find(q: String): List<String> {
        val k = q.trim().lowercase()
        if (k.isEmpty()) return emptyList()
        val re = Regex("(?<![0-9a-z])" + Regex.escape(k) + "(?![0-9a-z])")
        return rows.filter { r -> r.split(",").take(2).any { re.containsMatchIn(it.lowercase()) } }.take(8)
    }
}
