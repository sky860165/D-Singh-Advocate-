package com.dsingh.advocate

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.File
import java.io.RandomAccessFile
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object SecureStore {
    private const val ALIAS = "dsa_key"
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return g.generateKey()
    }
    fun enc(s: String): String {
        if (s.isEmpty()) return ""
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key())
            val ct = c.doFinal(s.toByteArray())
            "enc:" + Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)
        } catch (e: Exception) { s }
    }
    fun dec(s: String): String {
        if (!s.startsWith("enc:")) return s
        return try {
            val b = Base64.decode(s.removePrefix("enc:"), Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, b.copyOfRange(0, 12)))
            String(c.doFinal(b.copyOfRange(12, b.size)))
        } catch (e: Exception) { "" }
    }
}

object Crypt {
    private val MAGIC = byteArrayOf(68, 83, 65, 49)

    private fun keys(p: String, salt: ByteArray): Pair<ByteArray, ByteArray> {
        val k = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(p.toCharArray(), salt, 120000, 512)).encoded
        return Pair(k.copyOfRange(0, 32), k.copyOfRange(32, 64))
    }

    fun isEnc(f: File): Boolean = try {
        f.inputStream().use { val b = ByteArray(4); it.read(b) == 4 && b.contentEquals(MAGIC) }
    } catch (e: Exception) { false }

    fun encrypt(src: File, dst: File, pass: String) {
        val r = SecureRandom()
        val salt = ByteArray(16); r.nextBytes(salt)
        val iv = ByteArray(16); r.nextBytes(iv)
        val (ek, mk) = keys(pass, salt)
        val c = Cipher.getInstance("AES/CBC/PKCS5Padding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(ek, "AES"), IvParameterSpec(iv))
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(mk, "HmacSHA256"))
        dst.outputStream().buffered().use { out ->
            out.write(MAGIC); out.write(salt); out.write(iv); mac.update(iv)
            src.inputStream().buffered().use { ins ->
                val buf = ByteArray(65536)
                var n = ins.read(buf)
                while (n >= 0) {
                    val o = c.update(buf, 0, n)
                    if (o != null && o.isNotEmpty()) { out.write(o); mac.update(o) }
                    n = ins.read(buf)
                }
            }
            val last = c.doFinal()
            out.write(last); mac.update(last)
            out.write(mac.doFinal())
        }
    }

    fun decrypt(src: File, dst: File, pass: String): Boolean {
        return try {
            val total = src.length()
            if (total < 36L + 16L + 32L) return false
            RandomAccessFile(src, "r").use { raf ->
                val head = ByteArray(36)
                raf.readFully(head)
                if (!head.copyOfRange(0, 4).contentEquals(MAGIC)) return false
                val salt = head.copyOfRange(4, 20)
                val iv = head.copyOfRange(20, 36)
                val (ek, mk) = keys(pass, salt)
                val mac = Mac.getInstance("HmacSHA256")
                mac.init(SecretKeySpec(mk, "HmacSHA256"))
                mac.update(iv)
                val bodyLen = total - 36L - 32L
                val buf = ByteArray(65536)
                var left = bodyLen
                while (left > 0) {
                    val n = raf.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (n < 0) return false
                    mac.update(buf, 0, n); left -= n
                }
                val tag = ByteArray(32)
                raf.readFully(tag)
                if (!MessageDigest.isEqual(tag, mac.doFinal())) return false
                raf.seek(36L)
                val c = Cipher.getInstance("AES/CBC/PKCS5Padding")
                c.init(Cipher.DECRYPT_MODE, SecretKeySpec(ek, "AES"), IvParameterSpec(iv))
                dst.outputStream().buffered().use { out ->
                    left = bodyLen
                    while (left > 0) {
                        val n = raf.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (n < 0) return false
                        val o = c.update(buf, 0, n)
                        if (o != null && o.isNotEmpty()) out.write(o)
                        left -= n
                    }
                    out.write(c.doFinal())
                }
            }
            true
        } catch (e: Exception) { false }
    }
}

object Logx {
    private lateinit var f: File
    fun init(ctx: Context) {
        f = File(ctx.filesDir, "error.log")
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            add("CRASH " + t.name + ": " + e.stackTraceToString())
            old?.uncaughtException(t, e)
        }
    }
    fun add(s: String) {
        try {
            if (f.length() > 200000L) f.writeText("")
            f.appendText(java.time.LocalDateTime.now().toString() + " " + s + "\n")
        } catch (e: Exception) { }
    }
    fun read(): String = try { f.readText().takeLast(6000) } catch (e: Exception) { "" }
    fun clear() { try { f.writeText("") } catch (e: Exception) { } }
}
