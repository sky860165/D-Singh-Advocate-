package com.dsingh.advocate

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale

object PdfMaker {
    private fun jpegBytes(f: File, maxDim: Int, q: Int): Triple<ByteArray, Int, Int> {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > maxDim * 2 || o.outHeight / s > maxDim * 2) s *= 2
        val raw = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
            ?: throw IllegalStateException("image decode failed")
        val rot = when (ExifInterface(f.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        val sc = minOf(1f, maxDim.toFloat() / maxOf(raw.width, raw.height))
        val m = Matrix()
        m.postRotate(rot)
        m.postScale(sc, sc)
        val bmp = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
        val bo = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, q, bo)
        val res = Triple(bo.toByteArray(), bmp.width, bmp.height)
        if (bmp !== raw) raw.recycle()
        bmp.recycle()
        return res
    }

    fun fromJpegs(ctx: Context, files: List<File>, name: String, small: Boolean): File {
        val maxDim = if (small) 1240 else 1654
        val q = if (small) 60 else 80
        val out = File(File(ctx.cacheDir, "exports").apply { mkdirs() }, Docs.safe(name) + ".pdf")
        val offs = ArrayList<Long>()
        var pos = 0L
        val os = out.outputStream().buffered()
        fun wb(b: ByteArray) { os.write(b); pos += b.size }
        fun ws(s: String) { wb(s.toByteArray(Charsets.ISO_8859_1)) }
        fun mark() { offs.add(pos) }
        val n = files.size
        ws("%PDF-1.4\n")
        mark(); ws("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")
        mark(); ws("2 0 obj\n<< /Type /Pages /Kids [" + (0 until n).joinToString(" ") { (3 + 3 * it).toString() + " 0 R" } + "] /Count " + n + " >>\nendobj\n")
        files.forEachIndexed { i, f ->
            val (bytes, w, h) = jpegBytes(f, maxDim, q)
            val pg = 3 + 3 * i
            val ct = pg + 1
            val im = pg + 2
            val s = minOf(595.0 / w, 842.0 / h)
            val dw = w * s
            val dh = h * s
            val content = "q %.2f 0 0 %.2f %.2f %.2f cm /Im0 Do Q".format(Locale.US, dw, dh, (595.0 - dw) / 2, (842.0 - dh) / 2)
            mark(); ws("$pg 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /XObject << /Im0 $im 0 R >> >> /Contents $ct 0 R >>\nendobj\n")
            mark(); ws("$ct 0 obj\n<< /Length " + content.length + " >>\nstream\n" + content + "\nendstream\nendobj\n")
            mark(); ws("$im 0 obj\n<< /Type /XObject /Subtype /Image /Width $w /Height $h /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " + bytes.size + " >>\nstream\n")
            wb(bytes); ws("\nendstream\nendobj\n")
        }
        val total = 2 + 3 * n
        val xr = pos
        ws("xref\n0 " + (total + 1) + "\n0000000000 65535 f \n")
        for (k in 0 until total) ws("%010d 00000 n \n".format(Locale.US, offs[k]))
        ws("trailer\n<< /Size " + (total + 1) + " /Root 1 0 R >>\nstartxref\n" + xr + "\n%%EOF\n")
        os.close()
        return out
    }
}
