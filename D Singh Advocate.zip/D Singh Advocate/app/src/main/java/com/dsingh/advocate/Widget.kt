package com.dsingh.advocate

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class HearingWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        Repo.init(ctx)
        for (id in ids) mgr.updateAppWidget(id, build(ctx))
    }

    companion object {
        fun build(ctx: Context): RemoteViews {
            val td = today().toString()
            val act = Repo.cases.filter { it.active }
            val hs = act.filter { it.next == td }
            val tm = act.count { dayDiff(it.next) == 1L }
            val od = act.count { (dayDiff(it.next) ?: 0L) < 0L }
            val body = (if (hs.isEmpty()) "Aaj koi hearing nahi" else "Aaj (" + hs.size + "):\n" + hs.take(5).joinToString("\n") { "• " + it.title }) +
                "\nKal: " + tm + " hearings" + (if (od > 0) "\n⚠ " + od + " cases ki tareekh nikal gayi" else "")
            val rv = RemoteViews(ctx.packageName, R.layout.widget)
            rv.setTextViewText(R.id.wbody, body)
            rv.setOnClickPendingIntent(R.id.wroot, PendingIntent.getActivity(ctx, 1, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            return rv
        }

        fun refresh(ctx: Context) {
            try {
                val m = AppWidgetManager.getInstance(ctx)
                val ids = m.getAppWidgetIds(ComponentName(ctx, HearingWidget::class.java))
                for (id in ids) m.updateAppWidget(id, build(ctx))
            } catch (e: Exception) { }
        }
    }
}
