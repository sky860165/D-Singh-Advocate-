package com.dsingh.advocate

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

// ------------------------------------------------------------ network state
object Net {
    var online by mutableStateOf(true)
    private var started = false

    private fun check(cm: ConnectivityManager): Boolean {
        val c = cm.getNetworkCapabilities(cm.activeNetwork)
        return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    fun init(ctx: Context) {
        if (started) return
        started = true
        val app = ctx.applicationContext
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        online = try { check(cm) } catch (e: Exception) { true }
        try {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    val ok = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                    online = ok
                    if (ok) AiQueue.process(app)
                }
                override fun onLost(network: Network) { online = try { check(cm) } catch (e: Exception) { false } }
            })
        } catch (e: Exception) { Logx.add("net callback: " + e.toString()) }
    }
}

// ------------------------------------------------------------ AI queue (offline requests)
data class QItem(val id: String, val label: String, val prompt: String, val system: String,
                 val map: Map<String, String>, val created: String, val status: String, val result: String)

object AiQueue {
    var items by mutableStateOf(listOf<QItem>())
    private lateinit var ctx: Context
    private var running = false
    private fun f() = File(ctx.filesDir, "aiq.json")

    fun init(c: Context) {
        ctx = c.applicationContext
        try {
            val a = JSONArray(f().readText())
            items = (0 until a.length()).map {
                val o = a.getJSONObject(it)
                val mo = o.optJSONObject("map")
                val m = LinkedHashMap<String, String>()
                if (mo != null) mo.keys().forEach { k -> m[k] = mo.optString(k) }
                QItem(o.optString("id"), o.optString("label"), o.optString("prompt"), o.optString("system"), m,
                    o.optString("created"), o.optString("status"), o.optString("result"))
            }
        } catch (e: Exception) { }
    }

    private fun save() {
        try {
            f().writeText(JSONArray(items.map {
                JSONObject().put("id", it.id).put("label", it.label).put("prompt", it.prompt).put("system", it.system)
                    .put("map", JSONObject(it.map)).put("created", it.created).put("status", it.status).put("result", it.result)
            }).toString())
        } catch (e: Exception) { }
    }

    fun add(prompt: String, label: String, system: String) {
        items = items + QItem(UUID.randomUUID().toString().take(8), label, Anon.mask(prompt), system, HashMap(Anon.map),
            today().toString(), "pending", "")
        save()
    }

    fun delete(id: String) { items = items.filter { it.id != id }; save() }

    private fun update(id: String, st: String, res: String) {
        items = items.map { if (it.id == id) it.copy(status = st, result = res) else it }
        save()
    }

    private fun notifyDone(label: String) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("ai", "AI jawab", NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(ctx, 2, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            nm.notify(label.hashCode(), Notification.Builder(ctx, "ai").setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("AI jawab taiyar").setContentText(label).setContentIntent(open).setAutoCancel(true).build())
        } catch (e: Exception) { }
    }

    fun process(c: Context) {
        if (running) return
        if (items.none { it.status == "pending" }) return
        running = true
        CoroutineScope(Dispatchers.IO).launch {
            try {
                for (q in items.filter { it.status == "pending" }) {
                    Anon.map = q.map
                    Ai.netFail = false
                    val r = Ai.ask(q.prompt, q.system, queue = false)
                    if (r.startsWith("ERR")) {
                        if (Ai.netFail) break
                        update(q.id, "failed", r)
                    } else {
                        update(q.id, "done", r)
                        notifyDone(q.label)
                    }
                }
            } finally { running = false }
        }
    }
}

// ------------------------------------------------------------ local (offline) hearing-update parser
object LocalParse {
    data class Result(val date: String?, val cases: List<Case>, val matched: Boolean)

    private val months = mapOf(
        "jan" to 1, "january" to 1, "janvari" to 1, "जनवरी" to 1,
        "feb" to 2, "february" to 2, "farvari" to 2, "फरवरी" to 2,
        "mar" to 3, "march" to 3, "मार्च" to 3,
        "apr" to 4, "april" to 4, "aprail" to 4, "अप्रैल" to 4,
        "may" to 5, "mai" to 5, "मई" to 5,
        "jun" to 6, "june" to 6, "जून" to 6,
        "jul" to 7, "july" to 7, "julai" to 7, "जुलाई" to 7,
        "aug" to 8, "august" to 8, "agast" to 8, "अगस्त" to 8,
        "sep" to 9, "sept" to 9, "september" to 9, "sitambar" to 9, "सितंबर" to 9, "सितम्बर" to 9,
        "oct" to 10, "october" to 10, "aktubar" to 10, "अक्टूबर" to 10, "अक्तूबर" to 10,
        "nov" to 11, "november" to 11, "navambar" to 11, "नवंबर" to 11, "नवम्बर" to 11,
        "dec" to 12, "december" to 12, "disambar" to 12, "दिसंबर" to 12, "दिसम्बर" to 12
    )
    private val stop = setOf("vs", "versus", "state", "the", "and", "shri", "smt", "mr", "mrs", "ms", "case", "ke", "ki", "ka", "of", "in", "for")

    private fun norm(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) sb.append(if (ch in '०'..'९') ('0' + (ch - '०')) else ch)
        return sb.toString()
    }

    fun parseDate(raw: String): String? {
        val t = norm(raw)
        val now = today()
        fun fix(d: Int, m: Int, yIn: Int?): String? {
            return try {
                var y = yIn ?: now.year
                if (y < 100) y += 2000
                var dt = java.time.LocalDate.of(y, m, d)
                if (yIn == null && dt.isBefore(now)) dt = dt.plusYears(1)
                dt.toString()
            } catch (e: Exception) { null }
        }
        val num = Regex("(\\d{1,2})\\s*[/.-]\\s*(\\d{1,2})(?:\\s*[/.-]\\s*(\\d{2,4}))?").find(t)
        if (num != null) {
            val ys = num.groupValues[3]
            val r = fix(num.groupValues[1].toInt(), num.groupValues[2].toInt(), if (ys.isEmpty()) null else ys.toInt())
            if (r != null) return r
        }
        val w = Regex("[\\p{L}\\p{M}]+|\\d+").findAll(t).map { it.value }.toList()
        for (i in w.indices) {
            val a = w[i].toIntOrNull()
            if (a != null && a in 1..31 && i + 1 < w.size) {
                val mm = months[w[i + 1]]
                if (mm != null) {
                    val y = if (i + 2 < w.size) w[i + 2].toIntOrNull()?.takeIf { it > 31 } else null
                    val r = fix(a, mm, y)
                    if (r != null) return r
                }
            }
            val mm2 = months[w[i]]
            if (mm2 != null && i + 1 < w.size) {
                val d2 = w[i + 1].toIntOrNull()
                if (d2 != null && d2 in 1..31) {
                    val r = fix(d2, mm2, null)
                    if (r != null) return r
                }
            }
        }
        val rel = Regex("(\\d{1,3})\\s*(?:din|days?|दिन)\\s*(?:baad|me|mein|में|बाद)").find(t)
        if (rel != null) return now.plusDays(rel.groupValues[1].toLong()).toString()
        if (w.any { it == "parson" || it == "parso" || it == "परसों" || it == "परसो" }) return now.plusDays(2).toString()
        if (w.any { it == "kal" || it == "tomorrow" || it == "कल" }) return now.plusDays(1).toString()
        if (w.any { it == "aaj" || it == "today" || it == "आज" }) return now.toString()
        if ((w.contains("next") && w.contains("week")) || (w.contains("agle") && w.contains("hafte"))) return now.plusDays(7).toString()
        return null
    }

    fun matchCases(raw: String, cases: List<Case>): List<Case> {
        val rx = Regex("[\\p{L}\\p{M}\\d]+")
        val words = rx.findAll(norm(raw)).map { it.value }.toSet()
        fun toks(s: String): List<String> = rx.findAll(norm(s)).map { it.value }.filter { it.length >= 3 && it !in stop }.toList()
        val scored = cases.map { c -> c to (toks(c.client) + toks(c.title)).distinct().count { it in words } }.filter { it.second > 0 }
        val best = scored.maxOfOrNull { it.second } ?: return emptyList()
        return scored.filter { it.second == best }.map { it.first }
    }

    fun parse(raw: String, active: List<Case>): Result {
        val m = matchCases(raw, active)
        return Result(parseDate(raw), if (m.isNotEmpty()) m else active.take(10), m.isNotEmpty())
    }
}

fun applyHearing(cs: Case, nx: String, note: String) {
    val cur = Repo.cases.find { it.id == cs.id } ?: cs
    Repo.upsert(cur.copy(next = nx, hearings = cur.hearings + Hearing(today().toString(), note, nx)))
}

// ------------------------------------------------------------ offline prep brief (no AI)
fun localBrief(c: Case): String {
    val sb = StringBuilder()
    sb.append("HEARING PREP BRIEF (offline)\n\n")
    sb.append(c.title + (if (c.no.isBlank()) "" else " (" + c.no + ")") + "\n" + c.court + (if (c.judge.isBlank()) "" else " · Judge: " + c.judge) + "\n")
    sb.append("Client: " + c.client + (if (c.opp.isBlank()) "" else "  vs  " + c.opp) + "\n")
    sb.append("Stage: " + c.stage.ifBlank { "—" } + "\nAgli tareekh: " + fmtD(c.next) + "\n\nAb tak ki history:\n")
    if (c.hearings.isEmpty()) sb.append("  (koi entry nahi)\n")
    else c.hearings.takeLast(8).forEach {
        sb.append("  " + fmtD(it.date) + ": " + it.note.ifBlank { "—" } + (if (it.next.isBlank()) "" else " → agli " + fmtD(it.next)) + "\n")
    }
    sb.append("\nPending tasks:\n")
    val tk = c.tasks.filter { !it.done }
    if (tk.isEmpty()) sb.append("  (koi nahi)\n") else tk.forEach { sb.append("  - " + it.text + " (" + fmtD(it.due) + ")\n") }
    sb.append("\nDocuments saath rakho:\n")
    if (c.docs.isEmpty()) sb.append("  (koi nahi)\n") else c.docs.forEach { sb.append("  - " + it.cat + ": " + it.name + "\n") }
    sb.append("\nFees baaki: " + inr(c.pending) + "\n")
    if (c.notes.isNotBlank()) sb.append("\nNotes: " + c.notes + "\n")
    if (c.analysis.isNotBlank()) sb.append("\nPichla AI analysis (short):\n" + c.analysis.take(800) + "\n")
    return sb.toString()
}
