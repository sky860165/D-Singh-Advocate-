package com.dsingh.advocate

object Calc {
    fun interest(p: Double, r: Double, days: Double, compound: Boolean): Double =
        if (compound) p * (Math.pow(1 + r / 100.0, days / 365.0) - 1) else p * r * days / 36500.0
}

object Reports {
    fun csvEsc(s: String): String =
        if (s.any { it == ',' || it == '"' || it == '\n' }) "\"" + s.replace("\"", "\"\"") + "\"" else s

    fun casesCsv(list: List<Case>): String {
        val sb = StringBuilder("Title,Case No,CNR,Court,Client,Phone,Opposite Party,Status,Stage,Next Hearing,Fees,Received,Pending\n")
        list.forEach {
            sb.append(listOf(it.title, it.no, it.cnr, it.court, it.client, it.phone, it.opp, it.status, it.stage, it.next,
                it.fee.toString(), it.paid.toString(), it.pending.toString()).joinToString(",") { x -> csvEsc(x) }).append("\n")
        }
        return sb.toString()
    }

    fun monthReport(list: List<Case>, ym: String): String {
        var rec = 0L
        var exp = 0L
        val lines = StringBuilder()
        list.forEach { c ->
            val r = c.pays.filter { it.date.startsWith(ym) }.sumOf { it.amount }
            val e = c.exps.filter { it.date.startsWith(ym) }.sumOf { it.amount }
            if (r > 0 || e > 0) lines.append(c.title + " (" + c.client + "): received " + inr(r) + ", kharcha " + inr(e) + "\n")
            rec += r; exp += e
        }
        val pend = list.filter { it.active && it.pending > 0 }.sortedByDescending { it.pending }
        return "MONTHLY REPORT: " + ym + "\n\nTotal received: " + inr(rec) + "\nTotal kharcha: " + inr(exp) + "\nNet: " + inr(rec - exp) +
            "\n\nCase-wise:\n" + lines.toString() + "\nPending fees (active cases):\n" +
            pend.joinToString("\n") { it.client + " – " + it.title + ": " + inr(it.pending) } + "\nTotal pending: " + inr(pend.sumOf { it.pending })
    }
}
