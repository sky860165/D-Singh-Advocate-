package com.dsingh.advocate

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Docs {
    val CATS = listOf("Petition", "Order", "Evidence", "Notice", "ID proof", "Draft", "Other")

    fun dir(ctx: Context, caseId: String): File = File(ctx.filesDir, "docs/" + caseId).apply { mkdirs() }
    fun safe(n: String): String = n.replace(Regex("[^A-Za-z0-9._-]"), "_").takeLast(60)
    fun file(ctx: Context, c: Case, d: DocItem): File = File(dir(ctx, c.id), d.file)

    fun nameOf(ctx: Context, u: Uri): String = try {
        ctx.contentResolver.query(u, null, null, null, null)?.use { cur ->
            if (cur.moveToFirst()) {
                val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) cur.getString(i) else null
            } else null
        } ?: "file"
    } catch (e: Exception) { "file" }

    fun addUri(ctx: Context, caseId: String, u: Uri, name: String, cat: String, mime: String) {
        val c = Repo.cases.find { it.id == caseId } ?: return
        val stored = UUID.randomUUID().toString().take(8) + "_" + safe(name)
        File(dir(ctx, caseId), stored).outputStream().use { o -> ctx.contentResolver.openInputStream(u)?.use { it.copyTo(o) } }
        Repo.upsert(c.copy(docs = c.docs + DocItem(UUID.randomUUID().toString().take(8), name, cat, stored, today().toString(), mime)))
    }

    fun addFile(ctx: Context, caseId: String, src: File, name: String, cat: String, mime: String) {
        val c = Repo.cases.find { it.id == caseId } ?: return
        val stored = UUID.randomUUID().toString().take(8) + "_" + safe(name)
        src.copyTo(File(dir(ctx, caseId), stored), true)
        Repo.upsert(c.copy(docs = c.docs + DocItem(UUID.randomUUID().toString().take(8), name, cat, stored, today().toString(), mime)))
    }
}

object ZipBackup {
    fun create(ctx: Context): File {
        val f = File(File(ctx.cacheDir, "exports").apply { mkdirs() }, "D-Singh-Advocate-backup.zip")
        ZipOutputStream(f.outputStream().buffered()).use { z ->
            z.putNextEntry(ZipEntry("cases.json")); z.write(Repo.export().toByteArray()); z.closeEntry()
            z.putNextEntry(ZipEntry("templates.json")); z.write(Templates.export().toByteArray()); z.closeEntry()
            val root = File(ctx.filesDir, "docs")
            root.walkTopDown().filter { it.isFile }.forEach { fl ->
                z.putNextEntry(ZipEntry("docs/" + fl.relativeTo(root).path.replace('\\', '/')))
                fl.inputStream().use { it.copyTo(z) }
                z.closeEntry()
            }
        }
        return f
    }

    fun restore(ctx: Context, u: Uri, pass: String = ""): Boolean = try {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val tmp = File(dir, "restore.tmp")
        ctx.contentResolver.openInputStream(u)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        var src = tmp
        var good = true
        if (Crypt.isEnc(tmp)) {
            val dec = File(dir, "restore.zip")
            good = Crypt.decrypt(tmp, dec, pass)
            src = dec
        }
        var ok = false
        if (good) {
            val root = File(ctx.filesDir, "docs").apply { mkdirs() }.canonicalFile
            ZipInputStream(src.inputStream().buffered()).use { zi ->
                var e = zi.nextEntry
                while (e != null) {
                    if (e.name == "cases.json") ok = Repo.import(zi.readBytes().toString(Charsets.UTF_8))
                    else if (e.name == "templates.json") Templates.import(zi.readBytes().toString(Charsets.UTF_8))
                    else if (e.name.startsWith("docs/") && !e.isDirectory) {
                        val out = File(ctx.filesDir, e.name).canonicalFile
                        if (out.path.startsWith(root.path + File.separator)) {
                            out.parentFile?.mkdirs()
                            out.outputStream().use { zi.copyTo(it) }
                        }
                    }
                    e = zi.nextEntry
                }
            }
        }
        tmp.delete(); File(dir, "restore.zip").delete()
        ok
    } catch (e: Exception) { false }
}

fun Context.openFile(f: File, mime: String) {
    val u = FileProvider.getUriForFile(this, packageName + ".files", f)
    try {
        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    } catch (e: Exception) { Toast.makeText(this, "Is file ko kholne wala app nahi mila", Toast.LENGTH_SHORT).show() }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DocsTab(c: Case) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pendU by remember { mutableStateOf<Uri?>(null) }
    var pendCam by remember { mutableStateOf<File?>(null) }
    var nm by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("Other") }
    var mimeP by remember { mutableStateOf("application/octet-stream") }
    var delD by remember { mutableStateOf<DocItem?>(null) }
    var ai by remember { mutableStateOf("") }
    var aiName by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var filt by remember { mutableStateOf("Sab") }
    var tplDlg by remember { mutableStateOf(false) }
    var scanPages by remember { mutableStateOf(listOf<File>()) }
    var scanTmp by remember { mutableStateOf<File?>(null) }
    var scanDlg by remember { mutableStateOf(false) }
    var small by remember { mutableStateOf(true) }
    val camFile = remember { File(File(ctx.cacheDir, "exports").apply { mkdirs() }, "cam.jpg") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { pendU = u; nm = Docs.nameOf(ctx, u); mimeP = ctx.contentResolver.getType(u) ?: "application/octet-stream" }
    }
    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) { pendCam = camFile; nm = "Scan_" + today(); mimeP = "image/jpeg" }
    }
    val scan = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = scanTmp
        if (ok && f != null) { scanPages = scanPages + f; scanDlg = true }
    }
    val nextScan = {
        val f = File(File(ctx.cacheDir, "exports").apply { mkdirs() }, "scan_" + scanPages.size + ".jpg")
        scanTmp = f
        scan.launch(FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f))
    }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ pick.launch(arrayOf("*/*")) }) { Text("+ File") }
            Button({ cam.launch(FileProvider.getUriForFile(ctx, ctx.packageName + ".files", camFile)) }) { Text("📷 Scan") }
            Button({ tplDlg = true }) { Text("📄 Template") }
            Button({ scanPages = emptyList(); nextScan() }) { Text("📑 Multi-page") }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            (listOf("Sab") + Docs.CATS).forEach { k -> FilterChip(filt == k, { filt = k }, { Text(k) }) }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 6.dp))
        LazyColumn {
            items(c.docs.filter { filt == "Sab" || it.cat == filt }.reversed()) { d ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Column(Modifier.padding(10.dp)) {
                    Text(d.name, fontWeight = FontWeight.Bold, maxLines = 2)
                    Text(d.cat + " · " + fmtD(d.date), style = MaterialTheme.typography.bodySmall)
                    Row {
                        TextButton({ ctx.openFile(Docs.file(ctx, c, d), d.mime) }) { Text("Open") }
                        TextButton({ ctx.shareFile(Docs.file(ctx, c, d), d.mime) }) { Text("Share") }
                        if (!c.noAi && (d.mime == "application/pdf" || d.mime.startsWith("image"))) TextButton({
                            scope.launch {
                                busy = true; aiName = d.name
                                val b = withContext(Dispatchers.IO) { try { Docs.file(ctx, c, d).readBytes() } catch (e: Exception) { null } }
                                ai = if (b == null) "ERR: File padh nahi paya" else if (b.size > 15_000_000) "ERR: File 15MB se badi hai"
                                else Ai.ask(if (d.mime.startsWith("image")) Ai.ORDER else Ai.ANALYZE, pdf = b, mime = d.mime)
                                if (!ai.startsWith("ERR") && d.mime == "application/pdf")
                                    Repo.cases.find { it.id == c.id }?.let { Repo.upsert(it.copy(analysis = ai)) }
                                busy = false
                            }
                        }) { Text("AI") }
                        TextButton({ delD = d }) { Text("Delete") }
                    }
                } }
            }
            if (ai.isNotBlank()) item { OutBox(ai, aiName, c.id) }
        }
    }
    if (pendU != null || pendCam != null) {
        val close = { pendU = null; pendCam = null }
        AlertDialog(onDismissRequest = close, title = { Text("Document save karo") },
            text = { Column {
                F("Naam", nm) { nm = it }
                Text("Category", style = MaterialTheme.typography.bodySmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Docs.CATS.forEach { k -> FilterChip(cat == k, { cat = k }, { Text(k) }) }
                }
            } },
            confirmButton = { TextButton({
                val u = pendU; val cf = pendCam; val name = nm.ifBlank { "Document" }
                try {
                    if (u != null) Docs.addUri(ctx, c.id, u, name, cat, mimeP)
                    else if (cf != null) {
                        val ext = if (mimeP == "application/pdf") ".pdf" else ".jpg"
                        Docs.addFile(ctx, c.id, cf, if (name.endsWith(ext)) name else name + ext, cat, mimeP)
                        cf.delete()
                    }
                } catch (e: Exception) { Toast.makeText(ctx, "Save nahi ho paya", Toast.LENGTH_SHORT).show() }
                close()
            }) { Text("Save") } },
            dismissButton = { TextButton(close) { Text("Cancel") } })
    }
    if (tplDlg) AlertDialog(onDismissRequest = { tplDlg = false }, title = { Text("Template chuno") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) {
            if (Templates.list.isEmpty()) Text("Koi template nahi. Tools me Templates kholke banao ya Starter formats daalo.")
            Templates.list.forEach { t -> TextButton({ ai = Templates.fill(t.body, c); aiName = t.name; tplDlg = false }) { Text(t.name) } }
        } },
        confirmButton = { TextButton({ tplDlg = false }) { Text("Band") } })
    if (scanDlg) AlertDialog(onDismissRequest = { }, title = { Text("Scan: " + scanPages.size + " page") },
        text = { Column {
            Text("Aur page lo ya PDF banao.")
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(small, { small = it }); Text("Chhota size (court upload)") }
        } },
        confirmButton = { TextButton({
            scanDlg = false
            val pages = scanPages
            scope.launch {
                busy = true
                try {
                    val pdf = withContext(Dispatchers.Default) { PdfMaker.fromJpegs(ctx, pages, "Scan_" + today(), small) }
                    pages.forEach { it.delete() }
                    scanPages = emptyList()
                    pendCam = pdf; nm = "Scan_" + today(); mimeP = "application/pdf"
                } catch (e: Exception) {
                    Logx.add("scan pdf: " + e.toString())
                    Toast.makeText(ctx, "PDF nahi ban paya", Toast.LENGTH_SHORT).show()
                }
                busy = false
            }
        }) { Text("PDF banao") } },
        dismissButton = { Row {
            TextButton({ scanDlg = false; nextScan() }) { Text("+ Aur page") }
            TextButton({ scanPages.forEach { it.delete() }; scanPages = emptyList(); scanDlg = false }) { Text("Cancel") }
        } })
    val dd = delD
    if (dd != null) AlertDialog(onDismissRequest = { delD = null }, title = { Text("Ye file delete karein?") }, text = { Text(dd.name) },
        confirmButton = { TextButton({
            Docs.file(ctx, c, dd).delete()
            Repo.upsert(c.copy(docs = c.docs.filter { it.id != dd.id })); delD = null
        }) { Text("Delete") } },
        dismissButton = { TextButton({ delD = null }) { Text("Cancel") } })
}
