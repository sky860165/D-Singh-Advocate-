package com.dsingh.advocate

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.UUID

data class Hearing(val date: String, val note: String, val next: String)
data class Payment(val date: String, val amount: Long, val mode: String)
data class Comm(val date: String, val text: String)
data class Contact(val name: String, val role: String, val phone: String)
data class DocItem(val id: String, val name: String, val cat: String, val file: String, val date: String, val mime: String)
data class Todo(val id: String, val text: String, val due: String, val done: Boolean)
data class Case(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "", val no: String = "", val court: String = "", val judge: String = "",
    val type: String = "", val client: String = "", val phone: String = "", val opp: String = "",
    val status: String = "Active", val next: String = "", val fee: Long = 0, val notes: String = "",
    val hearings: List<Hearing> = emptyList(), val pays: List<Payment> = emptyList(),
    val comms: List<Comm> = emptyList(), val analysis: String = "",
    val exps: List<Payment> = emptyList(), val tasks: List<Todo> = emptyList(),
    val docs: List<DocItem> = emptyList(),
    val noAi: Boolean = false, val cnr: String = "", val stage: String = "",
    val stageLog: List<Comm> = emptyList(), val contacts: List<Contact> = emptyList()
) {
    val paid: Long get() = pays.sumOf { it.amount }
    val pending: Long get() = (fee - paid).coerceAtLeast(0L)
    val active: Boolean get() = status == "Active"
}

const val DEFAULT_MODEL = "gemini-4-hydrogen"
val MODEL_FALLBACKS = listOf("gemini-4-hydrogen", "gemini-3.8-flash", "gemini-3.5-flash-lite")
val OLD_MODELS = setOf("gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro", "gemini-2.0-flash", "gemini-2.0-flash-lite",
    "gemini-3.5-flash", "gemini-3.7-flash", "gemini-3-flash-preview", "gemini-3-pro-preview", "gemini-3.1-flash-lite-preview")

fun addD(s: String, n: Long, u: Char): String {
    val d = parseD(s) ?: return ""
    return (if (u == 'y') d.plusYears(n) else d.plusDays(n)).toString()
}
fun dayNote(s: String): String {
    val d = parseD(s) ?: return ""
    if (d.dayOfWeek == java.time.DayOfWeek.SUNDAY) return " ⚠ Sunday"
    if (Prefs.holidays.split(Regex("[,\\s]+")).contains(s)) return " ⚠ Holiday"
    return ""
}
fun signoff(): String = if (Prefs.name.isBlank()) "D Singh Advocate" else "Adv. " + Prefs.name
fun today(): LocalDate = LocalDate.now()
fun parseD(s: String): LocalDate? = try { LocalDate.parse(s) } catch (e: Exception) { null }
fun dayDiff(s: String): Long? = parseD(s)?.let { ChronoUnit.DAYS.between(today(), it) }
fun fmtD(s: String): String = parseD(s)?.format(DateTimeFormatter.ofPattern("d MMM yyyy")) ?: "—"
fun rel(s: String): String {
    val n = dayDiff(s) ?: return ""
    return when { n == 0L -> "Aaj"; n == 1L -> "Kal"; n < 0 -> "${-n} din pehle"; else -> "$n din baad" }
}
fun inr(n: Long): String = "₹" + "%,d".format(n)

fun ctxOf(c: Case): String = ctxRaw(c).also { if (Prefs.anon) Anon.set(c) }

fun ctxRaw(c: Case): String =
    "Title: ${c.title}\nCase No: ${c.no}\nCourt: ${c.court}\nJudge: ${c.judge}\nType: ${c.type}\n" +
    "Client: ${c.client}\nOpposite party: ${c.opp}\nNotes: ${c.notes}\nHearing history: " +
    c.hearings.joinToString("; ") { "${it.date}: ${it.note}" } + "\nAdvocate: ${Prefs.name}, Enrolment No: ${Prefs.enrol}, Address: ${Prefs.addr}, Phone: ${Prefs.phone}"

fun reminderMsg(c: Case): String =
    "Namaste ${c.client} ji, aapke case \"${c.title}\" ${if (c.no.isBlank()) "" else "(${c.no}) "}ki agli tareekh " +
    "${fmtD(c.next)} hai${if (c.court.isBlank()) "" else ", ${c.court} me"}. Kripya samay par upasthit rahein. " +
    "– " + signoff()

fun feeMsg(c: Case): String =
    "Namaste ${c.client} ji, case \"${c.title}\" me ${inr(c.pending)} fees baaki hai. Kripya jaldi vyavastha karein. " +
    "– " + signoff()

private fun <T> JSONArray?.list(f: (JSONObject) -> T): List<T> =
    if (this == null) emptyList() else (0 until length()).map { f(getJSONObject(it)) }

fun Case.toJson(): JSONObject = JSONObject().apply {
    put("id", id); put("title", title); put("no", no); put("court", court); put("judge", judge)
    put("type", type); put("client", client); put("phone", phone); put("opp", opp); put("status", status)
    put("next", next); put("fee", fee); put("notes", notes); put("analysis", analysis)
    put("hearings", JSONArray(hearings.map { JSONObject().put("d", it.date).put("n", it.note).put("x", it.next) }))
    put("pays", JSONArray(pays.map { JSONObject().put("d", it.date).put("a", it.amount).put("m", it.mode) }))
    put("comms", JSONArray(comms.map { JSONObject().put("d", it.date).put("t", it.text) }))
    put("exps", JSONArray(exps.map { JSONObject().put("d", it.date).put("a", it.amount).put("m", it.mode) }))
    put("tasks", JSONArray(tasks.map { JSONObject().put("i", it.id).put("t", it.text).put("d", it.due).put("x", it.done) }))
    put("docs", JSONArray(docs.map { JSONObject().put("i", it.id).put("n", it.name).put("c", it.cat).put("f", it.file).put("d", it.date).put("m", it.mime) }))
    put("noAi", noAi); put("cnr", cnr); put("stage", stage)
    put("slog", JSONArray(stageLog.map { JSONObject().put("d", it.date).put("t", it.text) }))
    put("contacts", JSONArray(contacts.map { JSONObject().put("n", it.name).put("r", it.role).put("p", it.phone) }))
}

fun caseFrom(o: JSONObject): Case = Case(
    id = o.optString("id", UUID.randomUUID().toString()), title = o.optString("title"), no = o.optString("no"),
    court = o.optString("court"), judge = o.optString("judge"), type = o.optString("type"),
    client = o.optString("client"), phone = o.optString("phone"), opp = o.optString("opp"),
    status = o.optString("status", "Active"), next = o.optString("next"), fee = o.optLong("fee"),
    notes = o.optString("notes"), analysis = o.optString("analysis"),
    hearings = o.optJSONArray("hearings").list { Hearing(it.optString("d"), it.optString("n"), it.optString("x")) },
    pays = o.optJSONArray("pays").list { Payment(it.optString("d"), it.optLong("a"), it.optString("m")) },
    comms = o.optJSONArray("comms").list { Comm(it.optString("d"), it.optString("t")) },
    exps = o.optJSONArray("exps").list { Payment(it.optString("d"), it.optLong("a"), it.optString("m")) },
    tasks = o.optJSONArray("tasks").list { Todo(it.optString("i"), it.optString("t"), it.optString("d"), it.optBoolean("x")) },
    docs = o.optJSONArray("docs").list { DocItem(it.optString("i"), it.optString("n"), it.optString("c"), it.optString("f"), it.optString("d"), it.optString("m")) },
    noAi = o.optBoolean("noAi"), cnr = o.optString("cnr"), stage = o.optString("stage"),
    stageLog = o.optJSONArray("slog").list { Comm(it.optString("d"), it.optString("t")) },
    contacts = o.optJSONArray("contacts").list { Contact(it.optString("n"), it.optString("r"), it.optString("p")) }
)

object Prefs {
    private lateinit var p: SharedPreferences
    fun init(c: Context) { p = c.getSharedPreferences("dsingh", 0) }
    var key: String
        get() = SecureStore.dec(p.getString("key", "") ?: "")
        set(v) { p.edit().putString("key", SecureStore.enc(v)).apply() }
    var model: String
        get() {
            val v = p.getString("model", "") ?: ""
            return if (v.isBlank() || v in OLD_MODELS) DEFAULT_MODEL else v
        }
        set(v) { p.edit().putString("model", v).apply() }
    var name: String
        get() = p.getString("name", "") ?: ""
        set(v) { p.edit().putString("name", v).apply() }
    var lock: Boolean
        get() = p.getBoolean("lock", false)
        set(v) { p.edit().putBoolean("lock", v).apply() }
    var bkUri: String
        get() = p.getString("bk", "") ?: ""
        set(v) { p.edit().putString("bk", v).apply() }
    var theme: Int
        get() = p.getInt("theme", 1)
        set(v) { p.edit().putInt("theme", v).apply() }
    var holidays: String
        get() = p.getString("hol", "") ?: ""
        set(v) { p.edit().putString("hol", v).apply() }
    var anon: Boolean
        get() = p.getBoolean("anon", false)
        set(v) { p.edit().putBoolean("anon", v).apply() }
    var ground: Boolean
        get() = p.getBoolean("ground", false)
        set(v) { p.edit().putBoolean("ground", v).apply() }
    var enrol: String
        get() = p.getString("enrol", "") ?: ""
        set(v) { p.edit().putString("enrol", v).apply() }
    var addr: String
        get() = p.getString("addr", "") ?: ""
        set(v) { p.edit().putString("addr", v).apply() }
    var phone: String
        get() = p.getString("phone", "") ?: ""
        set(v) { p.edit().putString("phone", v).apply() }
    var email: String
        get() = p.getString("email", "") ?: ""
        set(v) { p.edit().putString("email", v).apply() }
}

object Repo {
    var cases by mutableStateOf(listOf<Case>())
    private lateinit var ctx: Context
    private fun file() = File(ctx.filesDir, "cases.json")
    fun init(c: Context) { ctx = c.applicationContext; load() }
    private fun load() {
        try {
            val a = JSONArray(file().readText())
            cases = (0 until a.length()).map { caseFrom(a.getJSONObject(it)) }
        } catch (e: Exception) { }
    }
    private fun save() {
        try {
            val tmp = File(ctx.filesDir, "cases.tmp")
            tmp.writeText(JSONArray(cases.map { it.toJson() }).toString())
            tmp.renameTo(file())
        } catch (e: Exception) { Logx.add("save: " + e.toString()) }
        Reminders.scheduleAll(ctx)
        Backup.write(ctx)
        HearingWidget.refresh(ctx)
    }
    fun upsert(c: Case) {
        cases = if (cases.any { it.id == c.id }) cases.map { if (it.id == c.id) c else it } else cases + c
        save()
    }
    fun delete(id: String) {
        cases.find { it.id == id }?.let { Reminders.cancel(ctx, it) }
        File(ctx.filesDir, "docs/" + id).deleteRecursively()
        cases = cases.filter { it.id != id }
        save()
    }
    fun export(): String = JSONArray(cases.map { it.toJson() }).toString()
    fun import(s: String): Boolean = try {
        val a = JSONArray(s.trim())
        cases = (0 until a.length()).map { caseFrom(a.getJSONObject(it)) }
        save(); true
    } catch (e: Exception) { false }
}
